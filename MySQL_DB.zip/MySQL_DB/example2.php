<!DOCTYPE html>
<?php
include_once './source/MySQL_DB.class.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
        <link type="text/css" href="css/style.css" rel="stylesheet">
        <script type="text/javascript" src="js/ajax.js"></script>
        <script type="text/javascript" src="js/verification.js"></script>
        <script type="text/javascript" src="js/function.js"></script>
        <style>
            
        </style>
    </head>
    <body>
        <div id="message"></div>
        <form>
            <input id="id" type="hidden">
            <label for="name">Name </label><input id="name" type="text" maxlength="50"><br>
            <label for="email">Email</label><input id="email" type="email" maxlength="50"><br>
            <label for="address">Address </label><input id="address" type="text" maxlength="100"><br>
            <label for="notes">Notes </label><input id="notes" type="text" maxlength="200"><br>
            <label for="tel">Tel </label><textarea id="tel" rows="5"></textarea><br>
        </form>
        <div id="data">
            <button class="button" onclick="insertTable()">Insert</button>
            <button class="button" onclick="updateTable()">Update</button>
        </div>
        <div id="operation" style="float: left">
            
            <button class="button" onclick="creatDB()">Create Database</button><br>
            <button class="button" onclick="creatUser()">Create User</button><br>
            <button class="button" onclick="getCount()">Get Customer Count</button><br>
            <button class="button" onclick="getMin()">Get Customer ID Minimum</button><br>
            <button class="button" onclick="getMax()">Get Customer ID Maximum</button><br>
            <button class="button" onclick="getAverage()">Get Customer ID Average</button><br>
            <button class="button" onclick="backupDB()">Backup DB</button><br>
            <button class="button" onclick="backupUser()">Backup Users</button><br>
            <label for="restore">Select file to restore </label><input id="restore" type="file"><br>
            <button class="button" onclick="restoreDB()">Restore DB</button><br>
            <button class="button" onclick="getCustomer()">Reload Customer Table</button><br>
            <button class="button" onclick="getCustomerTel()">Reload Customer View</button>
        </div>
        <h2>Customer Table</h2>
        <table class="table" id="customers">
            <thead>
                <tr>
                    <td class="id">ID</td>
                    <td class="text">Name</td>
                    <td class="text">Email</td>
                    <td class="text">Address</td>
                    <td class="text">Notes</td>
                    <td class="text">Tel</td>
                    <td class="operation">Operations</td>
                </tr>
            </thead>
            <tbody id="customersData">
                <?php
                $customerData = getCustomerData();
                for ($i = 0; $i < count($customerData); $i++) {
                    $id = $customerData[$i]['id'];
                    $name = $customerData[$i]['name'];
                    $email = $customerData[$i]['email'];
                    $address = $customerData[$i]['address'];
                    $notes = $customerData[$i]['notes'];
                    $tel = getTelData($id);
                    $telText = '';
                    $telAreay = [];
                    for ($n = 0; $n < count($tel); $n++) {
                        $telText .= $tel[$n]['tel'] . '<br>';
                        $telAreay[] = $tel[$n]['tel'];
                    }
                    ?>
                    <tr id="c<?php echo "$id"; ?>">
                        <td class="id"><?php echo $id; ?></td>
                        <td class="text"><?php echo $name; ?></td>
                        <td class="text"><?php echo $email; ?></td>
                        <td class="text"><?php echo $address; ?></td>
                        <td class="text"><?php echo $notes; ?></td>
                        <td class="text"><?php echo $telText; ?></td>
                        <td class="operation">
                            <i class="fa fa-edit" onclick="editCustomer(this.parentNode.parentNode)" title="Edit this customer"></i>
                            <i class="fa fa-trash" onclick="deleteTable(<?php echo $id; ?>)" title="Delete this customer"></i>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
        <h2>Customer Tel. View</h2>
        <table class="table" id="customerTel">
            <thead>
                <tr>
                    <td class="id">ID</td>
                    <td class="text">Name</td>
                    <td class="text">Email</td>
                    <td class="text">Address</td>
                    <td class="text">Tel</td>
                </tr>
            </thead>
            <tbody id="customerTelData">
                <?php
                $customerTelData = getCustmerTelData();
                for ($i = 0; $i < count($customerTelData); $i++) {
                    $id = $customerTelData[$i]['custmerID'];
                    $name = $customerTelData[$i]['name'];
                    $email = $customerTelData[$i]['email'];
                    $address = $customerTelData[$i]['address'];
                    $tel = $customerTelData[$i]['tel'];
                    ?>
                    <tr>
                        <td class="id"><?php echo $id; ?></td>
                        <td class="text"><?php echo $name; ?></td>
                        <td class="text"><?php echo $email; ?></td>
                        <td class="text"><?php echo $address; ?></td>
                        <td class="text"><?php echo $tel; ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </body>
</html>
<?php

function getCustomerData() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $tenp = $db->select(['id', 'name', 'email', 'address', 'notes'], 'customer', []);
    if (is_array($tenp)) {
        return $tenp;
    } else {
        return [];
    }
}

function getTelData($id) {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $tenp = $db->select(['tel'], 'telephone', [['f' => 'custmerID', 'o' => '=', 'v' => $id]], 'AND');
    if (is_array($tenp)) {
        return $tenp;
    } else {
        return [];
    }
}

function getCustmerTelData() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $tenp = $db->select(['custmerID', 'name', 'email', 'address', 'tel'], 'customer_tel', []);
    if (is_array($tenp)) {
        return $tenp;
    } else {
        return [];
    }
}