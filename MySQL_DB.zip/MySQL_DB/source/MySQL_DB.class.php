<?php

date_default_timezone_set('Africa/Cairo');
//include_once '../file/file.class.php'; /* needed for bacup and restor function to compress and uncompress files */

/**
 * The MySQL DB class contain all MySQL database operation needed
 * @author Khaled Hassan
 * @category DataBase
 * @link khaled.h.developer@gmail.com
 */
class MySQL_DB {
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  PUPLIC CONSATNT USE AS ENUM VALUES  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    // ---------- CONSTANT NUMBER TYPES ---------- //

    /**
     * @var string The TINYINT column type accept from -128 to 127 <b>or</b> from 0 to 255.
     */
    public const TYPE_TINYINT = 'TINYINT';

    /**
     * @var string The SMALINT column type accept from --32768 to 32767 <b>or</b> from 0 to 65535.
     */
    public const TYPE_SMALINT = 'SMALINT';

    /**
     * @var string The MEDIUMINT column type accept from -8388608 to 8388607 <b>or</b> from 0 to 16777215.
     */
    public const TYPE_MEDIUMINT = 'MEDIUMINT';

    /**
     * @var string The INT column type accept from -2147483648 to 2147483647 <b>or</b> from 0 to 4294967295.
     */
    public const TYPE_INT = 'INT';

    /**
     * @var string The BIGINT column type accept from -9223372036854775808 to 9223372036854775807 <b>or</b> from 0 to 18446744073709551615.
     */
    public const TYPE_BIGINT = 'BIGINT';

    /**
     * @var string The SERIAL column type accept from 0 to 18446744073709551615 IS UNSIGNED NOT NULL AUTO_INCREMENT using in big Id field.
     */
    public const TYPE_SERIAL = 'SERIAL';

    /**
     * @var string The DECIMAL column type the maximum number of digits (M) is 65 <b>(default 10)</b>, the maximum number of decimals (D) is 30 <b>(default 0)</b>.
     */
    public const TYPE_DECIMAL = 'DECIMAL';

    /**
     * @var string The FLOAT column type accept from -3.402823466E+38 to -1.175494351E-38, <b>or</b> from 1.175494351E-38 to 3.402823466E+38.
     */
    public const TYPE_FLOAT = 'FLOAT';

    /**
     * @var string The DOUBLE column type accept from -1.7976931348623157E+308 to -2.2250738585072014E-308, <b>or</b> from 2.2250738585072014E-308 to 1.7976931348623157E+308.
     */
    public const TYPE_DOUBLE = 'DOUBLE';

    /**
     * @var string The REAL column type like DOUBLE (exception: in REAL_AS_FLOAT SQL mode it is a like FLOAT).
     */
    public const TYPE_REAL = 'REAL';

    /**
     * @var string The BOOLEAN column type a TINYINT(1), <br> <b>0</b> for false,  <b>1</b> for true".
     */
    public const TYPE_BOOLEAN = 'BOOLEAN';

    // ---------- CONSTANT STRING TYPES ---------- //

    /**
     * @var string The CHAR column type a fixed-length (0-255, default 1) string that is always right-padded with spaces to the specified length when stored.
     */
    public const TYPE_CHAR = 'CHAR';

    /**
     * @var string The VARCHAR column type a variable-length (0-65,535) string, the effective maximum length is subject to the maximum row size.
     */
    public const TYPE_VARCHAR = 'VARCHAR';

    /**
     * @var string The TINYTEXT column type a TEXT column with a maximum length of 255 (2^8 - 1) characters, stored with a one-byte prefix indicating the length of the value in bytes.
     */
    public const TYPE_TINYTEXT = 'TINYTEXT';

    /**
     * @var string The TEXT column type a TEXT column with a maximum length of 65,535 (2^16 - 1) characters, stored with a two-byte prefix indicating the length of the value in bytes
     */
    public const TYPE_TEXT = 'TEXT';

    /**
     * @var string The MEDIUMTEXT column type a TEXT column with a maximum length of 16,777,215 (2^24 - 1) characters, stored with a three-byte prefix indicating the length of the value in bytes.
     */
    public const TYPE_MEDIUMTEXT = 'MEDIUMTEXT';

    /**
     * @var string The LONGTEXT column type a TEXT column with a maximum length of 4,294,967,295 or 4GiB (2^32 - 1) characters, stored with a four-byte prefix indicating the length of the value in bytes.
     */
    public const TYPE_LONGTEXT = 'LONGTEXT';

    // ---------- CONSTANT DATE TYPES ---------- //

    /**
     * @var string The DATE column type accept supported range is 1000-01-01 to 9999-12-31.
     */
    public const TYPE_DATE = 'DATE';

    /**
     * @var string The TIME column type a accept range is -838:59:59 to 838:59:59.
     */
    public const TYPE_TIME = 'TIME';

    /**
     * @var string The DATETIME column type accept range is 1000-01-01 00:00:00 to 9999-12-31 23:59:59.
     */
    public const TYPE_DATETIME = 'DATETIME';

    /**
     * @var string The TIMESTAMP column type accept range is 1970-01-01 00:00:01 UTC to 2038-01-09 03:14:07 UTC, stored as the number of seconds since the epoch (1970-01-01 00:00:00 UTC).
     */
    public const TYPE_TIMESTAMP = 'TIMESTAMP';

    /**
     * @var string The DATE column type a year in four-digit (4, default) or two-digit (2) format, the allowable values are 70 (1970) to 69 (2069) or 1901 to 2155 and 0000.
     */
    public const TYPE_YEAR = 'YEAR';

    // ---------- CONSTANT FIELD ATTRIBUTES ---------- //

    /**
     * @var string The field attributes UNSIGNED.
     */
    public const ATTRIBUTES_UNSIGNED = 'UNSIGNED';

    /**
     * @var string The field attributes UNSIGNED ZEROFILL.
     */
    public const ATTRIBUTES_UNSIGNED_ZEROFILL = 'UNSIGNED ZEROFILL';

    /**
     * @var string The field attributes on update CURRENT_TIMESTAMP.
     */
    public const ATTRIBUTES_ON_UPDATE_CURRENT_TIMESTAMP = 'on update CURRENT_TIMESTAMP';

    // ---------- CONSTANT RELATION TYPE ---------- //

    /**
     * @var string The on delete and or update relation type don't take action.
     */
    public const RELATION_NO_ACTION = 'NO ACTION';

    /**
     * @var string The on delete and or update relation type don't take action an cancel delete or update operation from parent table.
     */
    public const RELATION_RESTRICT = 'RESTRICT ';

    /**
     * @var string The on delete and or update relation type set null in childe table in field type accept that.
     */
    public const RELATION_SET_NULL = 'SET NULL';

    /**
     * @var string The on delete and or update relation type change in childe table when change in parent table.
     */
    public const RELATION_CASCADE = 'CASCADE';

    // ---------- CONSTANT FIELD DEFAULT ---------- //

    /**
     * @var string The field default NULL.
     */
    public const DEFAULT_NULL = 'NULL';

    /**
     * @var string The field default NOT NULL.
     */
    public const DEFAULT_NOT_NULL = 'NOT YULL';

    /**
     * @var string The field default CURRENT_TIMESTAMP.
     */
    public const DEFAULT_CURRENT_TIMESTAMP = 'CURRENT_TIMESTAMP';

    // ---------- CONSTANT USER PERMISSIONS ---------- //

    /**
     * @var string The user permission can select from tables and view.
     */
    public const PERMISSION_SELECT = 'SELECT';

    /**
     * @var string The user permission can insert in database tables.
     */
    public const PERMISSION_INSERT = 'INSERT';

    /**
     * @var string The user permission can update in database table.
     */
    public const PERMISSION_UPDATE = 'UPDATE';

    /**
     * @var string The user permission can delete from database tables.
     */
    public const PERMISSION_DELETE = 'DELETE';

    /**
     * @var string The user permission can create database and table.
     */
    public const PERMISSION_CREATE = 'CREATE';

    /**
     * @var string The user permission can create view.
     */
    public const PERMISSION_CREATE_VIEW = 'CREATE VIEW';

    /**
     * @var string The user permission can alter tables structure.
     */
    public const PERMISSION_ALTER = 'ALTER';

    /**
     * @var string The user permission can drop (delete) database, table & view.
     */
    public const PERMISSION_DROP = 'DROP';

    /**
     * @var string The user permission can import or export data files.
     */
    public const PERMISSION_FILE = 'FILE';

    /**
     * @var string The user permission can create or drop index.
     */
    public const PERMISSION_INDEX = 'INDEX';

    /**
     * @var string The user permission can create stored routine.
     */
    public const PERMISSION_CREATE_ROUTINE = 'CREATE ROUTINE';

    /**
     * @var string The user permission can alter stored routine.
     */
    public const PERMISSION_ALTER_ROUTINE = 'ALTER ROUTINE';

    /**
     * @var string The user permission can execute stored routine.
     */
    public const PERMISSION_EXECUTE = 'EXECUTE';

    /**
     * @var string The user permission can create or drop triggers.
     */
    public const PERMISSION_TRIGGER = 'TRIGGER';

    /**
     * @var string The user permission can create another users accounts.
     */
    public const PERMISSION_CREATE_USER = 'CREATE USER';

    /**
     * @var string The user permission can add user and privileges (add user to database) without load privileges tabel.
     */
    public const PERMISSION_GRANT = 'GRANT';

    /**
     * @var string The user permission queries and operation over maximum allowed limit.
     */
    public const PERMISSION_SUPER = 'SUPER';

    /**
     * @var string The user permission can lock table from another user to finish thread.
     */
    public const PERMISSION_LOCK_TABLES = 'LOCK TABLES';

    /**
     * @var string The user permission have compleat access to all database in this server.
     */
    public const PERMISSION_SHOW_DATABASES = 'SHOW DATABASES';

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  VARIABLE USING AS PROPERTY & PUBULIC VALUES  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    // ---------- PUBLIC PROPERTY ---------- //

    /**
     * @var int The number of rows in every select statement 0 return all rows.
     */
    public $pageCapacity = 0;

    /**
     * @var int Return the total pages calculate after run select function.
     */
    public $totalPages = 0;

    /**
     * @var string The host name or IP address of database server.
     */
    public $host = 'localhost';

    /**
     * @var string The database name to connect it.
     */
    public $databaseName = '';

    /**
     * @var string the database user name.
     */
    public $user = 'root';

    /**
     * @var string The password of database user.
     */
    public $password = '';

    /**
     * @var string The path of backup directory.
     */
    public $backupDirectory = '';

    /**
     * @var object The variable store connection object to database.
     */
    public $con;

    // ---------- PRIVATE PROPERTY & CONSTANT ---------- //

    /**
     * @var string The character set of data in database.
     */
    const CHARSET = 'utf8';

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  CONSTRUCT & SESTRUCT  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * construct class and create connection
     * @param string $dbName [optional] <br> The name of database. <p></p>
     * @param string $host [optional] <br> The host name or IP for mySQL server. <p></p>
     * @param string $user [optional] <br> The user name of database. <p></p>
     * @param string $password [optional] <br> The password of database user. <br> <b>false</b> is default value means don't have password. <p></p>
     * @param int $pageCapacity [optional] <br> The number of rows in every select statement. <p></p>
     * @param string $backupDirectory [optional] <br> The path of backup directory. <br> <b>false</b> is default value means don't set directory. <p></p>
     */
    function __construct($dbName = '', $host = 'localhost', $user = 'root', $password = false, $pageCapacity = 0, $backupDirectory = false) {
        $this->databaseName = $dbName;
        $this->host = $host;
        $this->user = $user;
        if ($password !== false) {
            $this->password = $password;
            $this->connect($dbName, $host, $user, $password);
        }

        if ($backupDirectory) {
            $this->backupDirectory = $backupDirectory;
        }

        $this->pageCapacity = $pageCapacity;
    }

    /**
     * destruct class and kill connection
     */
    function __destruct() {
        if ($this->con) {
            $this->con = NULL;
        }
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  CONNECT OR RECONNECT TO MYSQL DATABASE  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Connect or reconnect to database with another options.
     * @param string $dbName [optional] <br> The name of database. <b>false</b> is default value means don't set database name. <p></p>
     * @param string $host [optional] <br> The host name or IP for mySQL server. <b>localhost</b> is default value. <p></p>
     * @param string $user [optional] <br> The user name of database. <b>false</b> is default value means don't set user name and take from property $dbuser. <p></p>
     * @param string $password [optional] <br> The password of database user. <br> <b>false</b> is default value means don't set password. <p></p>
     * @return oject <br> The PDO connection object.
     */
    public function connect($dbName = false, $host = 'localhost', $user = false, $password = false) {
        if (!$dbName) {
            $dbName = '';
        } else {
            $this->databaseName = $dbName;
        }
        if (!$user) {
            $user = $this->user;
        } else {
            $this->user = $user;
        }
        if (!$password) {
            $password = '';
        } else {
            $this->password = $password;
        }
        $this->host = $host;


        $this->con = new PDO('mysql:dbhost=' . $host . ';dbname=' . $dbName . ';charset=' . self::CHARSET, $user, $password);
        $this->con->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
        $this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $this->con;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  PUBLIC FUNCTION FOR DATAVASE STRUCTURE  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Create new database.
     * @param string $dbName <br> The database name. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function createDatabase($dbName) {
        $sql = $this->con->prepare("CREATE DATABASE IF NOT EXISTS `$dbName` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin; COMMIT;");
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete database if exist.
     * @param string $dbName <br> The database name. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropDatabase($dbName) {
        $sql = $this->con->prepare("DROP DATABASE IF EXISTS `$dbName`; COMMIT;");
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Create new user with specific permissions.
     * @param string $userName <br> The user name. <p></p>
     * @param string $password <br> The user password. <p></p>
     * @param string $host <br> The user host can connect from it. <p></p>
     * @param array $permission <br> The array contain permissions string. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function creatUser($userName, $password, $host, $permission) {
        $available = [self::PERMISSION_ALTER, self::PERMISSION_ALTER_ROUTINE, self::PERMISSION_CREATE,
            self::PERMISSION_CREATE_ROUTINE, self::PERMISSION_CREATE_USER, self::PERMISSION_CREATE_VIEW,
            self::PERMISSION_DELETE, self::PERMISSION_DROP, self::PERMISSION_EXECUTE, self::PERMISSION_FILE,
            self::PERMISSION_GRANT, self::PERMISSION_INDEX, self::PERMISSION_INSERT, self::PERMISSION_LOCK_TABLES,
            self::PERMISSION_SELECT, self::PERMISSION_SHOW_DATABASES, self::PERMISSION_SUPER, self::PERMISSION_TRIGGER, self::PERMISSION_UPDATE];

        $option = '';
        for ($i = 0; $i < count($permission); $i++) {
            if (in_array($permission[$i], $available)) {
                $option .= $permission[$i] . ', ';
            }
        }

        if (strlen($option) > 2) {
            $option = substr($option, 0, strlen($option) - 2);
        } else {
            return false;
        }

        if (in_array('GRANT', $permission)) {
            $sql = $this->con->prepare("GRANT $option ON *.* TO '$userName'@'$host' IDENTIFIED BY '$password' WITH GRANT OPTION; COMMIT;");
        } else {
            $sql = $this->con->prepare("GRANT $option ON *.* TO '$userName'@'$host' IDENTIFIED BY '$password'; COMMIT;");
        }

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Add existing user to specific database with permissions.
     * @param string $userName <br> The user name. <p></p>
     * @param string $host <br> The user host can connect from it. <p></p>
     * @param array $permission <br> The array contain permissions string. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function addUserToDB($userName, $dbName, $host, $permission) {
        $available = [self::PERMISSION_ALTER, self::PERMISSION_ALTER_ROUTINE, self::PERMISSION_CREATE,
            self::PERMISSION_CREATE_ROUTINE, self::PERMISSION_CREATE_VIEW, self::PERMISSION_DELETE, self::PERMISSION_DROP,
            self::PERMISSION_EXECUTE, self::PERMISSION_GRANT, self::PERMISSION_INDEX, self::PERMISSION_INSERT,
            self::PERMISSION_LOCK_TABLES, self::PERMISSION_SELECT, self::PERMISSION_TRIGGER, self::PERMISSION_UPDATE];

        $option = '';
        for ($i = 0; $i < count($permission); $i++) {
            if (in_array($permission[$i], $available)) {
                $option .= $permission[$i] . ', ';
            }
        }

        if (strlen($option) > 2) {
            $option = substr($option, 0, strlen($option) - 2);
        } else {
            return false;
        }

        if (in_array('GRANT', $permission)) {
            $sql = $this->con->prepare("GRANT $option ON `$dbName`.* TO '$userName'@'$host' WITH GRANT OPTION; COMMIT;");
        } else {
            $sql = $this->con->prepare("GRANT $option ON `$dbName`.* TO '$userName'@'$host'; COMMIT;");
        }

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Change password of user.
     * @param string $userName <br> The user name. <p></p>
     * @param string $password <br> The user password. <p></p>
     * @param string $host <br> The user host can connect from it. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function changeUserPassword($userName, $password, $host) {
        $sql = $this->con->prepare("SET PASSWORD FOR '$userName'@'$host' = PASSWORD('$password'); COMMIT;");

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete user from all database and delete from MySQL server users.
     * @param string $userName <br> The user name. <p></p>
     * @param string $host <br> The user host can connect from it. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropUser($userName, $host) {
        $sql = $this->con->prepare("REVOKE ALL PRIVILEGES, GRANT OPTION FROM '$userName'@'$host'; DROP USER '$userName'@'$host'; COMMIT;");

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Create new table in database.
     * @param string $tableName <br> The new table name name. <p></p>
     * @param array $tableFields <br> The associative array contain fields data. <br> <b>like</b> [['name' => 'field_name', 'type' => MySQL_DB::TYPE_INT, 'length' => 10, 'default' => MySQL_DB::DEFAULT_NOT_NULL, 'attributes' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'comment' => 'test field'], ...]. <br> <b>Or</b> [['n' => 'field_name', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'test field'], ...]. <p></p>
     * @param string $primaryKeyName <br> The primary key field name. <p></p>
     * @param bool $autoIncrementId <br> The primary key field auto increment or not. <p></p>
     * @param string $tableComment [optional] <br> The table comments. <p></p>
     * @param bool $dropOldTable [optional] <br> <b>true</b> drop table if exists, <b>false</b> don't drop table and don't create table if exists. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function createTable($tableName, $tableFields, $primaryKeyName, $autoIncrementId, $tableComment = '', $dropOldTable = false, $databaseName = '') {
        $val = $this->dropTableIfExist($tableName, $dropOldTable, $databaseName);
        if (!$val) {
            return false;
        }

        $fields = '(';
        for ($i = 0; $i < count($tableFields); $i++) {
            $fields .= $this->getCreateTableField($tableFields[$i], $primaryKeyName, $autoIncrementId);
        }
        if (trim($primaryKeyName) !== '') {
            $fields .= "PRIMARY KEY (`$primaryKeyName`))";
        } else {
            $fields = substr($fields, 0, strlen($fields) - 2) . ')';
        }

        if (trim($databaseName) !== '') {
            $sql = "CREATE TABLE `$databaseName`.`$tableName` $fields ENGINE = InnoDB CHARACTER SET " . self::CHARSET;
        } else {
            $sql = "CREATE TABLE `$tableName` $fields ENGINE = InnoDB CHARACTER SET " . self::CHARSET;
        }
        if (trim($tableComment) !== '') {
            $sql .= " COLLATE utf8_bin COMMENT = '$tableComment'; COMMIT;";
        } else {
            $sql .= " COLLATE utf8_bin; COMMIT;";
        }

        $sql = $this->con->prepare($sql);
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Add new Column to table.
     * @param string $tableName <br> The new table name name. <p></p>
     * @param array $tableFields <br> The associative array contain fields data. <br> <b>like</b> [['name' => 'field_name', 'type' => MySQL_DB::TYPE_INT, 'length' => 10, 'default' => MySQL_DB::DEFAULT_NOT_NULL, 'attributes' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'comment' => 'test field'], ...]. <br> <b>Or</b> [['n' => 'field_name', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'test field'], ...]. <p></p>
     * @param string $fieldAfter <br> The name of field will add new fields after it. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function addTableColumn($tableName, $tableFields, $fieldAfter, $databaseName = '') {
        if (trim($fieldAfter) === '') {
            return false;
        }

        $fields = '';
        for ($i = 0; $i < count($tableFields); $i++) {
            if ($i === 0) {
                $after = $fieldAfter;
            } else {
                if (isset($tableFields[$i - 1]['name'])) {
                    $after = trim($tableFields[$i - 1]['name']);
                } elseif (isset($tableFields[$i - 1]['n'])) {
                    $after = trim($tableFields[$i - 1]['n']);
                } else {
                    $after = '';
                }
            }
            $fields .= $this->getAddTableField($tableFields[$i], $after);
        }
        $fields = substr($fields, 0, strlen($fields) - 2);

        if (trim($databaseName) !== '') {
            $sql = "ALTER TABLE `$databaseName`.`$tableName` ADD $fields; COMMIT;";
        } else {
            $sql = "ALTER TABLE `$tableName` ADD $fields; COMMIT;";
        }

        $sql = $this->con->prepare($sql);
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete column from table.
     * @param string $tableName <br> The name of table want delete fields from it. <p></p>
     * @param array $columns <br> The array contain fields name string. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropTableColumn($tableName, $columns, $databaseName = '') {
        if (is_array($columns) && count($columns) > 0) {
            $sql = '';
            for ($i = 0; $i < count($columns); $i++) {
                $sql .= 'DROP `' . $columns[$i] . '`, ';
            }

            if (strlen($sql) > 2) {
                $sql = substr($sql, 0, strlen($sql) - 2);
            }
        } elseif (strlen($columns) > 0) {
            $sql = "DROP `$columns`";
        } else {
            return false;
        }

        if (trim($databaseName) !== '') {
            $sql = $this->con->prepare("ALTER TABLE `$databaseName`.`$tableName` $sql; COMMIT;");
        } else {
            $sql = $this->con->prepare("ALTER TABLE `$tableName` $sql; COMMIT;");
        }

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Add index to table column.
     * @param string $tableName <br> The name of tablet. <p></p>
     * @param string $fieldName <br> The field name want add index to it. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function addTableIndex($tableName, $fieldName, $databaseName = '') {
        if (trim($databaseName) !== '') {
            $sql = $this->con->prepare("ALTER TABLE `$databaseName`.`$tableName` ADD INDEX `$fieldName-I` (`$fieldName`); COMMIT;");
        } else {
            $sql = $this->con->prepare("ALTER TABLE `$tableName` ADD INDEX `$fieldName-I` (`$fieldName`); COMMIT;");
        }

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete index from table column.
     * @param string $tableName <br> The name of table. <p></p>
     * @param string $fieldName <br> The field name want delete index from it. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropTableInex($tableName, $fieldName, $databaseName = '') {
        if (trim($databaseName) !== '') {
            $sql = $this->con->prepare("ALTER TABLE `$databaseName`.`$tableName` DROP KEY `$fieldName-I`; COMMIT;");
        } else {
            $sql = $this->con->prepare("ALTER TABLE `$tableName` DROP KEY `$fieldName-I`; COMMIT;");
        }

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Add unique to table column.
     * @param string $tableName <br> The name of tablet. <p></p>
     * @param string $fieldName <br> The field name want add unique to it. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function addTableUnique($tableName, $fieldName, $databaseName = '') {
        if (trim($databaseName) !== '') {
            $sql = $this->con->prepare("ALTER TABLE `$databaseName`.`$tableName` ADD UNIQUE `$fieldName-U` (`$fieldName`); COMMIT;");
        } else {
            $sql = $this->con->prepare("ALTER TABLE `$tableName` ADD UNIQUE `$fieldName-U` (`$fieldName`); COMMIT;");
        }

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete unique from table column.
     * @param string $tableName <br> The name of table. <p></p>
     * @param string $fieldName <br> The field name want delete unique from it. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropTableUnique($tableName, $fieldName, $databaseName = '') {
        if (trim($databaseName) !== '') {
            $sql = $this->con->prepare("ALTER TABLE `$databaseName`.`$tableName` DROP KEY `$fieldName-U`; COMMIT;");
        } else {
            $sql = $this->con->prepare("ALTER TABLE `$tableName` DROP KEY `$fieldName-U`; COMMIT;");
        }

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete unique from table column.
     * @param string $childeTable <br> The name of childe table. <p></p>
     * @param string $foreignKeyField <br> The field name related field in childe table. <p></p>
     * @param string $parentTable <br> The name of parent table. <p></p>
     * @param string $referenceField <br> The field name related field in parent table. <p></p>
     * @param string $onUpdate [optional] <br> The action type when update in parent table. <p></p>
     * @param string $onDelete [optional] <br> The action type when delete from parent table. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function addTablesRelation($childeTable, $foreignKeyField, $parentTable, $referenceField, $onUpdate = self::RELATION_NO0_ACTION, $onDelete = self::RELATION_NO0_ACTION, $databaseName = '') {
        $actionType = [self::RELATION_CASCADE, self::RELATION_NO_ACTION, self::RELATION_RESTRICT, self::RELATION_SET_NULL];
        if (!in_array($onUpdate, $actionType)) {
            $onUpdate = self::RELATION_NO_ACTION;
        }
        if (!in_array($onDelete, $actionType)) {
            $onDelete = self::RELATION_NO_ACTION;
        }

        if ($databaseName !== '') {
            $sql = "ALTER TABLE `$databaseName`.`$childeTable` ADD CONSTRAINT `$childeTable-$foreignKeyField-FK` FOREIGN KEY (`$foreignKeyField`) REFERENCES `$databaseName`.`$parentTable` (`$referenceField`) ON UPDATE $onUpdate ON DELETE $onDelete; COMMIT;";
        } else {
            $sql = "ALTER TABLE `$childeTable` ADD CONSTRAINT `$childeTable-$foreignKeyField-FK` FOREIGN KEY (`$foreignKeyField`) REFERENCES `$parentTable` (`$referenceField`) ON UPDATE $onUpdate ON DELETE $onDelete; COMMIT;";
        }

        $sql = $this->con->prepare($sql);
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete unique from table column.
     * @param string $childeTable <br> The name of childe table. <p></p>
     * @param string $foreignKeyField <br> The field name related field in childe table. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropTablesRelation($childeTable, $foreignKeyField, $databaseName = '') {
        if ($databaseName !== '') {
            $sql = "ALTER TABLE `$databaseName`.`$childeTable` DROP FOREIGN KEY `$childeTable-$foreignKeyField-FK`; COMMIT;";
        } else {
            $sql = "ALTER TABLE `$childeTable` DROP FOREIGN KEY `$childeTable-$foreignKeyField-FK`; COMMIT;";
        }

        $sql = $this->con->prepare($sql);
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete table from database.
     * @param string $tableName <br> The name of table want delete it. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropTable($tableName, $databaseName = '') {
        if (is_array($tableName) && count($tableName) > 0) {
            for ($i = 0; $i < count($tableName); $i++) {
                $val = $this->dropTableIfExist($tableName[$i], true, $databaseName);
                if (!$val) {
                    return false;
                }
            }
        } elseif (strlen($tableName) > 0) {
            $val = $this->dropTableIfExist($tableName, true, $databaseName);
            if (!$val) {
                return false;
            }
        } else {
            return false;
        }

        return true;
    }

    /**
     * Delete all table data <b>(empty it)</b>.
     * @param string $tableName <br> The name of table want delete data from it. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function truncateTable($tableName, $databaseName) {
        if (is_array($tableName) && count($tableName) > 0) {
            $sql = '';
            for ($i = 0; $i < count($tableName); $i++) {
                if ($databaseName !== '') {
                    $sql .= "`$databaseName`.`" . $tableName[$i] . '`, ';
                } else {
                    $sql .= "`" . $tableName[$i] . '`, ';
                }
            }
            if (strlen($sql) > 2) {
                $sql = substr($sql, 0, strlen($sql) - 2);
            }
        } elseif (strlen($tableName) > 0) {
            if ($databaseName !== '') {
                $sql = "`$databaseName`.`$tableName`";
            } else {
                $sql = "`$tableName`";
            }
        } else {
            return false;
        }

        $sql = $this->con->prepare("TRUNCATE $sql; COMMIT;");
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Create new view in database.
     * @param string $viewName <br> The new view name. <p></p>
     * @param array $viewFields <br> The associative array contain fields data. <br> <b>like</b> [['table' => 'table_name', 'column' => 'column_name', 'name' => 'new_name'], ...]. <br> <b>Or</b> [['t' => 'table_name', 'c' => 'column_name', 'n' => 'new_name'], ...]. <br> If not set the new name in array function will use same column name. <p></p>
     * @param string $linkedColumn <br> The associative array contain table column will related from it. <br> <b>Like</b> [['table1' => 'name', 'column1' => 'name', 'table2' => 'name', 'column2' => 'name'], ...]. <br> <b>or</b> [['t1' => 'name', 'c1' => 'name', 't2' => 'name', 'c2' => 'name'], ...] <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['table' => 'table_name', 'field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['t' => 'table_name', 'f' => 'field1', 'o' => '=', 'v' => 'test'], ['t' => 'table_name', 'f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @param bool $dropOldView [optional] <br> <b>true</b> drop table if exists, <b>false</b> don't drop table and don't create table if exists. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function creatView($viewName, $viewFields, $linkedColumn, $where = [], $nextCondetion = 'AND', $dropOldView = false, $databaseName = '') {
        $val = $this->dropTableIfExist($viewName, $dropOldView, $databaseName);
        if (!$val) {
            return false;
        }

        $fields = $this->getViewField($viewFields, $databaseName);
        $temp = $this->getViewLinked($linkedColumn, $databaseName);
        $tables = $temp['table'];
        $linked = $temp['linked'];

        $condition = $this->getViewWhere($linked, $where, $nextCondetion, $databaseName);

        if ($fields === '' || $tables === '' || $linked === '') {
            return false;
        }

        if (trim($databaseName) !== '') {
            $sql = "CREATE VIEW `$databaseName`.`$viewName` AS select $fields from $tables $condition; COMMIT;";
        } else {
            $sql = "CREATE VIEW `$viewName` AS select $fields from $tables $condition; COMMIT;";
        }

        $sql = $this->con->prepare($sql);
        $this->setWhereValues($sql, $where);
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete all view data <b>(empty it)</b>.
     * @param string $viewName <br> The name of view want delete it. <p></p>
     * @param array $viewName <br> The array contain name of view want delete it. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function dropView($viewName) {
        if (is_array($viewName) && count($viewName) > 0) {
            $sql = '';
            for ($i = 0; $i < count($viewName); $i++) {
                $sql .= '`' . $viewName[$i] . '`, ';
            }
            $sql = substr($sql, 0, strlen($sql) - 2);
        } elseif (strlen($viewName) > 0) {
            $sql = "`$viewName`";
        } else {
            return false;
        }

        $sql = $this->con->prepare("DROP VIEW $sql; COMMIT;");
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Get all database.
     * @param string $databaseName [optional] <br> The name of database want get table inside it or send empty value will use the database in connection. <p></p>
     * @return array contain all tables in database.
     */
    public function getAllDatabase() {
        $sql = $this->con->prepare("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA");
        try {
            if ($sql->execute() !== false) {
                $database = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $database[] = $fetch[0];
                }

                return $database;
            } else {
                return [];
            }
        } catch (Exception $ex) {
            return [];
        }
    }

    /**
     * Check if database exist.
     * @param string $databaseName <br> The name of database want check exist. <p></p>
     * @return array contain all tables in database.
     */
    public function checkDatabaseExist($databaseName) {
        $sql = $this->con->prepare("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$databaseName'");
        try {
            if ($sql->execute() !== false) {
                $database = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $database[] = $fetch[0];
                }

                if (count($database) === 1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Get all users.
     * @param string $databaseName [optional] <br> The name of database want get table inside it or send empty value will use the database in connection. <p></p>
     * @return array contain all tables in database.
     */
    public function getAllUsers() {
        $sql = $this->con->prepare("select User, Host from mysql.user;");
        try {
            if ($sql->execute() !== false) {
                $users = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $users[] = ['User' => $fetch[0], 'Host' => $fetch[1]];
                }

                return $users;
            } else {
                return [];
            }
        } catch (Exception $ex) {
            return [];
        }
    }

    /**
     * Check if user exist.
     * @param string $userName <br> The name of user want check exist. <p></p>
     * @param string $host <br> The host of user want check exist. <p></p>
     * @return array contain all tables in database.
     */
    public function checkUserExist($userName, $host) {
        $sql = $this->con->prepare("select User from mysql.user WHERE User = '$userName' AND Host = '$host'");
        try {
            if ($sql->execute() !== false) {
                $user = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $user[] = $fetch[0];
                }

                if (count($user) === 1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Check all data about user.
     * @param string $userName <br> The name of user want check exist. <p></p>
     * @param string $host <br> The host of user want check exist. <p></p>
     * @return array contain all tables in database.
     */
    public function getUserData($userName, $host) {
        $sql = $this->con->prepare("select * from mysql.user WHERE User = '$userName' AND Host = '$host'");
        try {
            if ($sql->execute() !== false) {
                $users = [];
                while ($fetch = $sql->fetch(PDO::FETCH_ASSOC)) {
                    $users[] = $fetch;
                }

                return $users;
            } else {
                return [];
            }
        } catch (Exception $ex) {
            return [];
        }
    }

    /**
     * Get all database tables.
     * @param string $databaseName [optional] <br> The name of database want get table inside it or send empty value will use the database in connection. <p></p>
     * @return array contain all tables in database.
     */
    public function getDatabaseTables($databaseName = '') {
        $tables = [];
        if (trim($databaseName) !== '') {
            $sql = "SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = '$databaseName' AND TABLE_TYPE LIKE '%TABLE%'";
        } else {
            $sql = "SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = '$this->databaseName' AND TABLE_TYPE LIKE '%TABLE%'";
        }

        $sql = $this->con->prepare($sql);
        try {
            if ($sql->execute() !== false) {
                $tables = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $tables[] = $fetch[0];
                }

                return $tables;
            } else {
                return [];
            }
        } catch (Exception $ex) {
            return [];
        }
    }

    /**
     * Check if database exist.
     * @param string $databaseName <br> The name of database contain the table. <p></p>
     * @param string $tableName <br> The name of table want check exist. <p></p>
     * @return array contain all tables in database.
     */
    public function checkTableExist($databaseName, $tableName) {
        $sql = $this->con->prepare("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = '$databaseName' AND TABLE_NAME = '$tableName' AND TABLE_TYPE LIKE '%TABLE%'");
        try {
            if ($sql->execute() !== false) {
                $tables = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $tables[] = $fetch[0];
                }

                if (count($tables) === 1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Get all database views.
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return array contain all views in database.
     */
    public function getDatabaseViews($databaseName = '') {
        $views = [];
        if (trim($databaseName) !== '') {
            $sql = "SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = '$databaseName' AND TABLE_TYPE LIKE '%VIEW%'";
        } else {
            $sql = "SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = '$this->databaseName' AND TABLE_TYPE LIKE '%VIEW%'";
        }

        $sql = $this->con->prepare($sql);
        try {
            if ($sql->execute() !== false) {
                $views = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $views[] = $fetch[0];
                }

                return $views;
            } else {
                return [];
            }
        } catch (Exception $ex) {
            return [];
        }
    }

    /**
     * Check if database exist.
     * @param string $databaseName <br> The name of database contain the view. <p></p>
     * @param string $viewName <br> The name of view want check exist. <p></p>
     * @return array contain all tables in database.
     */
    public function checkViewExist($databaseName, $viewName) {
        $sql = $this->con->prepare("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = '$databaseName' AND TABLE_NAME = '$viewName' AND TABLE_TYPE LIKE '%VIEW%'");
        try {
            if ($sql->execute() !== false) {
                $views = [];
                while ($fetch = $sql->fetch(PDO::FETCH_NUM)) {
                    $views[] = $fetch[0];
                }

                if (count($views) === 1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  PUBLIC FUNCTION FRO DATABASE OPERATIONS  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Get the number of rows in table or view.
     * @param string $tableName <br> The table name we get the rows count. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @param string $columnName [optional] <br> The column name to select. <br>  '' means * (all columns). <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return int <b>The rows number</b> on success or <b>false</b> on failure.
     */
    public function table_count($tableName, $where = [], $nextCondetion = 'AND', $columnName = '', $databaseName = '') {
        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($databaseName !== '') {
            if ($columnName === '') {
                $sql = "SELECT COUNT(*) From `$databaseName`.`$tableName` $condition";
            } else {
                $sql = "SELECT COUNT(`$columnName`) From `$databaseName`.`$tableName` $condition";
            }
        } else {
            if ($columnName === '') {
                $sql = "SELECT COUNT(*) From `$tableName` $condition";
            } else {
                $sql = "SELECT COUNT(`$columnName`) From `$tableName` $condition";
            }
        }

        $sql = $this->con->prepare($sql);
        $this->setWhereValues($sql, $where);
        try {
            if ($sql->execute() !== false) {
                $temp = $sql->fetch(PDO::FETCH_BOTH);
                $count = (int) $temp[0];
                return $count;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Get the sum of column values.
     * @param string $tableName <br> The table name. <p></p>
     * @param string $columnName <br> The column name to select and sum values. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return int <b>The column sum</b> on success or <b>false</b> on failure.
     */
    public function column_sum($tableName, $columnName, $where = [], $nextCondetion = 'AND', $databaseName = '') {
        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($databaseName !== '') {
            $sql = "SELECT SUM(`$columnName`) From `$databaseName`.`$tableName` $condition";
        } else {
            $sql = "SELECT SUM(`$columnName`) From `$tableName` $condition";
        }

        $sql = $this->con->prepare($sql);
        $this->setWhereValues($sql, $where);
        try {
            if ($sql->execute() !== false) {
                $temp = $sql->fetch(PDO::FETCH_BOTH);
                $sum = (int) $temp[0];
                return $sum;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Get the average of column values.
     * @param string $tableName <br> The table name. <p></p>
     * @param string $columnName <br> The column name to select and get avarage value (sum / count). <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return int <b>The column average value</b> on success or <b>false</b> on failure.
     */
    public function column_avarage($tableName, $columnName, $where = [], $nextCondetion = 'AND', $databaseName = '') {
        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($databaseName !== '') {
            $sql = "SELECT AVG(`$columnName`) From `$databaseName`.`$tableName` $condition";
        } else {
            $sql = "SELECT AVG(`$columnName`) From `$tableName` $condition";
        }

        $sql = $this->con->prepare($sql);
        $this->setWhereValues($sql, $where);
        try {
            if ($sql->execute() !== false) {
                $temp = $sql->fetch(PDO::FETCH_BOTH);
                $avarge = (int) $temp[0];
                return $avarge;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Get the maximum value in column.
     * @param string $tableName <br> The table name. <p></p>
     * @param string $columnName <br> The column name to select and get maximum values. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return int <b>The column maximum value</b> on success or <b>false</b> on failure.
     */
    public function column_max($tableName, $columnName, $where = [], $nextCondetion = 'AND', $databaseName = '') {
        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($databaseName !== '') {
            $sql = "SELECT MAX(`$columnName`) From `$databaseName`.`$tableName` $condition";
        } else {
            $sql = "SELECT MAX(`$columnName`) From `$tableName` $condition";
        }

        $sql = $this->con->prepare($sql);
        $this->setWhereValues($sql, $where);
        try {
            if ($sql->execute() !== false) {
                $temp = $sql->fetch(PDO::FETCH_BOTH);
                $max = $temp[0];
                return $max;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Get the minimum value in column.
     * @param string $tableName <br> The table name. <p></p>
     * @param string $columnName <br> The column name to select and get minimum values. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return int <b>The column minimum value</b> on success or <b>false</b> on failure.
     */
    public function column_Min($tableName, $columnName, $where = [], $nextCondetion = 'AND', $databaseName = '') {
        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($databaseName !== '') {
            $sql = "SELECT MIN(`$columnName`) From `$databaseName`.`$tableName` $condition";
        } else {
            $sql = "SELECT MIN(`$columnName`) From `$tableName` $condition";
        }

        $sql = $this->con->prepare($sql);
        $this->setWhereValues($sql, $where);
        try {
            if ($sql->execute() !== false) {
                $temp = $sql->fetch(PDO::FETCH_BOTH);
                $min = $temp[0];
                return $min;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Test if this value exist in table or not.
     * @param string $tableName <br> The table name. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $field [optional] <br> The field name to select <br> 'id' is default value. <p></p>
     * @return int <b>The column minimum value</b> on success or <b>false</b> on failure.
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return int <b>0</b> If value not exist <b>Positive number</b> The number of repeat this value if exist.
     */
    public function check_value_exist($tableName, $where, $field = 'id', $databaseName = '') {
        if ($field === '') {
            $field = 'id';
        }
        $condition = $this->getWhereValue($where, 'AND');
        if ($condition !== '') {
            if ($databaseName !== '') {
                $sql = "SELECT COUNT(`$field`) FROM `$databaseName`.`$tableName` $condition";
            } else {
                $sql = "SELECT COUNT(`$field`) FROM `$tableName` $condition";
            }

            $sql = $this->con->prepare($sql);
            $this->setWhereValues($sql, $where);
            try {
                if ($sql->execute() !== false) {
                    $temp = $sql->fetch(PDO::FETCH_BOTH);
                    $count = (int) $temp[0];
                    return $count;
                } else {
                    return 0;
                }
            } catch (Exception $ex) {
                return 0;
            }
        } else {
            return 0;
        }
    }

    /**
     * Test if this value exist in table or not but by send SQL statement.
     * @param string $SQL <br> The SQL statement code. <p></p>
     * @return int <b>0</b> If value not exist <b>Positive number</b> The number of repeat this value if exist.
     */
    public function free_check_value_exist($SQL) {
        $sql = $this->con->prepare($SQL);
        try {
            if ($sql->execute() !== false) {
                $temp = $sql->fetch(PDO::FETCH_BOTH);
                $count = (int) $temp[0];
                return $count;
            } else {
                return 0;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Generate unique Id for table in 13 characters.
     * @param string $tableName <br> The table name. <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return string 13 characters unique id.
     */
    public function generate_ID($tableName, $databaseName = '') {
        do {
            $id = $this->get_id();
            $val = $this->check_value_exist($tableName, ['id' => $id], 'id', $databaseName);
            if ($val === 0) {
                return $id;
            }
        } while (1 === 1);
    }

    /**
     * Generate new random password from characters, numbers and special characters ['@', '-', '_', '$', '#', '.'].
     * @return string contain new password.
     */
    public function generate_Password() {
        $char = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
        $symbol = ['@', '-', '_', '$', '#', '.'];
        $pass = $char[mt_rand(0, 25)] . $char[mt_rand(0, 25)] . $symbol[mt_rand(0, 5)] . $char[mt_rand(0, 25)] . $symbol[mt_rand(0, 5)] . mt_rand(0, 9) . $char[mt_rand(0, 25)] . mt_rand(0, 9);
        return $pass;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Make select data from database and return result in array.
     * @param array $fields <br> The array contain columns name. <p></p>
     * @param string $tableName <br> The table or view name to select it. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param array $orderField [optional] <br> The array contain columns name to order arrangement result by it, <p></p>
     * @param bool $orderAscending [optional] <br> <b>true</b> Order ascending <b>false</b> Order descending. <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @param int $currentPage [optional] <br> The page number if using limit in select <br>  to make effect must set pageCapacity property at the beginning <br>  and receive the total pages of this table in totalPages property. <p></p>
     * @return array <b>[['columnName' => value, ...], [['columnName' => value, ...]], ...]</b>.
     */
    public function select($fields, $tableName, $where = [], $nextCondetion = 'AND', $orderField = [], $orderAscending = true, $databaseName = '', $currentPage = 0) {
        $selected = $this->getFields($fields);

        if ($databaseName !== '') {
            if ($currentPage !== 0 && $this->pageCapacity !== 0) {
                $sql = "SELECT SQL_CALC_FOUND_ROWS $selected FROM `$databaseName`.`$tableName` ";
            } else {
                $sql = "SELECT $selected FROM `$databaseName`.`$tableName` ";
            }
        } else {
            if ($currentPage !== 0 && $this->pageCapacity !== 0) {
                $sql = "SELECT SQL_CALC_FOUND_ROWS $selected FROM `$tableName` ";
            } else {
                $sql = "SELECT $selected FROM `$tableName` ";
            }
        }


        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($condition !== '') {
            $sql .= " $condition";
        }

        if (is_array($orderField)) {
            if (count($orderField) !== 0) {
                $sort = ' ORDER BY ';
                foreach ($orderField as $field => $value) {
                    if ($orderAscending == true) {
                        $sort .= '`' . $value . '` ASC, ';
                    } else {
                        $sort .= '`' . $value . '` DESC, ';
                    }
                }
                $sort = substr($sort, 0, strlen($sort) - 2);
                $sql .= $sort;
            }
        }

        if ($currentPage > 0 && $this->pageCapacity > 0) {
            $from = ($currentPage - 1) * $this->pageCapacity;
            $sql .= " LIMIT $from , $this->pageCapacity";
        }

        $selected = null;
        $sql = $this->con->prepare($sql);
        $this->setWhereValues($sql, $where);
        try {
            if ($sql->execute() !== false) {
                while ($fetch = $sql->fetch(PDO::FETCH_ASSOC)) {
                    $selected[] = $fetch;
                }

                if ($this->pageCapacity !== 0) {
                    $total_rows = $this->table_count($tableName, $where, $nextCondetion, $fields[0], $databaseName);
                    $this->totalPages = ceil(($total_rows / $this->pageCapacity));
                }
            }
            return $selected;
        } catch (Exception $ex) {
            return [];
        }
    }

    /**
     * Make select data from database and return result in arrayy.
     * @param string $SQL <br> The SQL statement code for select. <p></p>
     * @return array <b>[['columnName' => value, ...], [['columnName' => value, ...]], ...]</b>.
     */
    public function freeSelect($SQL) {
        $Selected = null;
        $sql = $this->con->prepare("$SQL;  COMMIT;");
        try {
            if ($sql->execute() !== false) {
                while ($fetch = $sql->fetch(PDO::FETCH_ASSOC)) {
                    $Selected[] = $fetch;
                }
            }
            return $Selected;
        } catch (Exception $ex) {
            return [];
        }
    }

    /**
     * Insert data in database table.
     * @param array $data <br> The associative array contain column name and Value. <br>  ['columnName' => value, ...]. <p></p>
     * @param string $tableName <br> The table will put data it. <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function insert($data, $tableName, $databaseName = '') {
        $operation = $this->setFields($data);
        if ($operation !== '') {
            if ($databaseName !== '') {
                $sql = "INSERT INTO `$databaseName`.`$tableName` SET $operation";
            } else {
                $sql = "INSERT INTO `$tableName` SET $operation";
            }

            $sql = $this->con->prepare($sql);
            $this->setFieldsValue($sql, $data);
            try {
                if ($sql->execute() !== false) {
                    return $this->con->lastInsertId();
                }
            } catch (Exception $ex) {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Update (change) data specific id in database table.
     * @param array $data <br> The associative array contain column name and Value. <br>  ['columnName' => value, ...]. <p></p>
     * @param string $tableName <br> The table will put data it. <p></p>
     * @param string $id <br> The specific id to update data in his field (row). <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function update($data, $tableName, $id, $databaseName = '') {
        $operation = $this->setFields($data);
        if ($operation !== '') {
            if ($databaseName !== '') {
                $sql = "UPDATE `$databaseName`.`$tableName` SET $operation WHERE `id` = '$id'";
            } else {
                $sql = "UPDATE `$tableName` SET $operation WHERE `id` = '$id'";
            }

            $sql = $this->con->prepare($sql);
            $this->setFieldsValue($sql, $data);
            try {
                if ($sql->execute() !== false) {
                    return $id;
                } else {
                    return false;
                }
            } catch (Exception $ex) {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Update (change) 1 field (row) or more in database table with specific condition.
     * @param array $data <br> The associative array contain column name and Value. <br>  ['columnName' => value, ...]. <p></p>
     * @param string $tableName <br> The table will put data it. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> 'AND' the default value or 'OR'. <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function multiUpdate($data, $tableName, $where = [], $nextCondetion = 'AND', $databaseName = '') {
        $operation = $this->setFields($data);
        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($operation !== '' && $condition !== '') {
            if ($databaseName !== '') {
                $sql = "UPDATE `$databaseName`.`$tableName` SET $operation $condition";
            } else {
                $sql = "UPDATE `$tableName` SET $operation $condition";
            }

            $sql = $this->con->prepare($sql);
            $this->setFieldsValue($sql, $data);
            $this->setWhereValues($sql, $where);
            try {
                if ($sql->execute() !== false) {
                    return true;
                } else {
                    return false;
                }
            } catch (Exception $ex) {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Delete 1 field (row) for specific id from database table.
     * @param string $tableName <br> The table will put data it. <p></p>
     * @param string $id <br> The specific id to update data in his field (row). <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function delete($tableName, $id, $databaseName = '') {
        if ($databaseName !== '') {
            $sql = "DELETE FROM `$databaseName`.`$tableName` WHERE `id` = :id";
        } else {
            $sql = "DELETE FROM `$tableName` WHERE `id` = :id";
        }

        $sql = $this->con->prepare($sql);
        $sql->bindParam(':id', $id);
        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /**
     * Delete 1 field (row) or more from database table with specific condition.
     * @param string $tableName <br> The table will put data it. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> 'AND' the default value or 'OR'. <p></p>
     * @param string $databaseName [optional] <br> The name of database want get view inside it or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function multiDelete($tableName, $where, $nextCondetion = 'AND', $databaseName = '') {
        $condition = $this->getWhereValue($where, $nextCondetion);
        if ($condition !== '') {
            if ($databaseName !== '') {
                $sql = "DELETE FROM `$databaseName`.`$tableName` $condition";
            } else {
                $sql = "DELETE FROM `$tableName` $condition";
            }

            $sql = $this->con->prepare($sql);
            $this->setWhereValues($sql, $where);
            try {
                if ($sql->execute() !== false) {
                    return true;
                } else {
                    return false;
                }
            } catch (Exception $ex) {
                return false;
            }
        } else {
            return false;
        }
    }

    /* function to run query in the db by this conniction */

    /**
     * Run SQL statement code using class connection.
     * @param string $SQL <br> The SQL statement code. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function freeSQL($SQL) {
        $sql = $this->con->prepare("$SQL; COMMIT;");

        try {
            if ($sql->execute() !== false) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            return false;
        }
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  PUBLIC FUNCTION FOR BACKUP & RESTORE  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Backup database in text file and can be compress this file.
     * @param array $tables [optional] <br> '*' means all tables. <p></p>
     * @param string $databaseName [optional] <br> The name of database want backup it send, empty value will use the database in connection. <p></p>
     * @return string <b>File name</b> on success or <b>false</b> on failure.
     */
    public function backupDatabase($tables = '*', $databaseName = '') {
        if($databaseName === ''){
            $databaseName = $this->databaseName;
        }
        if($databaseName === ''){
            return false;
        }
        
        if (!is_array($tables) && $tables === '*') {
            $tables = $this->getDatabaseTables($databaseName);
        }
        $views = $this->getDatabaseViews($databaseName);

        $backupData = 'DROP DATABASE IF EXISTS `' . $databaseName . "`;\n";
        $backupData .= 'CREATE DATABASE `' . $databaseName . "` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;\n";
        $backupData .= 'USE ' . $databaseName . ";\n\n";

        foreach ($tables as $table) {
            $sql = 'DROP TABLE IF EXISTS `' . $table . '`;';
            $result = $this->con->query("SHOW CREATE TABLE `$databaseName`.`$table`");
            $row = $result->fetch(PDO::FETCH_NUM);
            $sql .= "\n\n" . $row[1] . ";\n\n";
            $numRows = $this->table_count($table);

            $batchSize = 1000;
            $numBatches = intval($numRows / $batchSize) + 1;
            for ($i = 1; $i <= $numBatches; $i++) {
                $query = "SELECT * FROM `$databaseName`.`$table` LIMIT " . ($i * $batchSize - $batchSize) . ',' . $batchSize;
                $result = $this->con->query($query);
                $numFields = $result->columnCount();

                for ($m = 0; $m < $numFields; $m++) {
                    $rowCount = 0;
                    while ($fetch = $result->fetch(PDO::FETCH_NUM)) {
                        $sql .= 'INSERT INTO `' . $table . '` VALUES(';
                        for ($n = 0; $n < $numFields; $n++) {
                            if (isset($fetch[$n])) {
                                $fetch[$n] = addslashes($fetch[$n]);
                                $fetch[$n] = str_replace("\n", "\\n", $fetch[$n]);
                                $sql .= '"' . $fetch[$n] . '"';
                            } else {
                                $sql .= 'NULL';
                            }

                            if ($n < ($numFields - 1)) {
                                $sql .= ',';
                            }
                        }
                        $sql .= ");\n";
                    }
                }

                $backupData .= $sql;
                $sql = '';
            }

            $backupData .= "\n\n\n";
        }

        foreach ($views as $view) {
            $sql = 'DROP VIEW IF EXISTS `' . $view . '`;';
            $result = $this->con->query("SHOW CREATE VIEW `$databaseName`.`$view`");
            $row = $result->fetch(PDO::FETCH_NUM);
            $sql .= "\n\n" . $row[1] . ";\n\n";

            $backupData .= $sql;
            $sql = '';

            $backupData .= "\n\n\n";
        }

        $backupData .= $this->BackupDatabaseUsers($databaseName);

        $file = $this->backupDirectory . $databaseName . '-' . date("Y-m-d_H-i", time()) . '.sql';
        $this->saveBackupFile($backupData, $file);

        return $file;
    }

    /**
     * restore database from backup file.
     * @param string $backupFile <br> The backup file name. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    public function restoreDatabase($backupFile) {
        $sql = '';
        $multiLineComment = false;

        $handle = fopen($backupFile, "r");
        if ($handle) {
            while (($line = fgets($handle)) !== false) {
                $line = ltrim(rtrim($line));
                if (strlen($line) > 1) { // avoid blank lines
                    $lineIsComment = false;
                    if (preg_match('/^\/\*/', $line)) {
                        $multiLineComment = true;
                        $lineIsComment = true;
                    }
                    if ($multiLineComment or preg_match('/^\/\//', $line)) {
                        $lineIsComment = true;
                    }
                    if (!$lineIsComment) {
                        $sql .= $line;
                        if (preg_match('/;$/', $line)) {
                            if ($this->freeSQL("$sql; COMMIT;")) {
                                $sql = '';
                            }
                        }
                    } else if (preg_match('/\*\/$/', $line)) {
                        $multiLineComment = false;
                    }
                }
            }
            fclose($handle);
        } else {
            throw new Exception("ERROR: couldn't open backup file $backupFile");
        }

        return true;
    }

    /**
     * Backup users of database.
     * @param string $databaeName <br> The name of database. <p></p>
     * @return string <b>SQL statement</b> on success or <b>false</b> on failure.
     */
    public function BackupDatabaseUsers($databaeName) {
        $script = '';
        $sql = "select * from mysql.db WHERE Db = '$databaeName';";
        $result = $this->con->query($sql);

        $database = [];
        while ($fetch = $result->fetch(PDO::FETCH_ASSOC)) {
            $database[] = $fetch;
        }

        for ($i = 0; $i < count($database); $i++) {
            $user = $database[$i]['User'];
            $host = $database[$i]['Host'];

            $databasePermission = $this->checkPrivileges($database[$i]);
            $databaseScript = "GRANT $databasePermission ON `$databaeName`.* TO '$user'@'$host';";

            $sql = "select * from mysql.user WHERE User = '$user' AND Host = '$host';";
            $result = $this->con->query($sql);

            $users = [];
            while ($fetch = $result->fetch(PDO::FETCH_ASSOC)) {
                $users[] = $fetch;
            }

            if (count($users) > 0) {
                $password = $users[0]['Password'];
                $grand = $users[0]['Grant_priv'];

                $userPermission = $this->checkPrivileges($users[0]);
                if ($grand === 'Y') {
                    $userScript = "GRANT $userPermission ON *.* TO '$user'@'$host' IDENTIFIED BY PASSWORD '$password' WITH GRANT OPTION;";
                } else {
                    $userScript = "GRANT $userPermission ON *.* TO '$user'@'$host' IDENTIFIED BY PASSWORD '$password';";
                }

                $script .= "$userScript\n\n$databaseScript\n\n\n";
            }
        }

        return $script;
    }

    /**
     * Backup all MySQL users.
     * @return string <b>File name</b> on success or <b>false</b> on failure.
     */
    public function BackupAllUsers() {
        $script = '';

        $sql = "select * from mysql.user;";
        $result = $this->con->query($sql);

        $users = [];
        while ($fetch = $result->fetch(PDO::FETCH_ASSOC)) {
            $users[] = $fetch;
        }

        for ($i = 0; $i < count($users); $i++) {
            $host = $users[$i]['Host'];
            $user = $users[$i]['User'];
            $password = $users[$i]['Password'];
            $grand = $users[$i]['Grant_priv'];

            if ($user === 'root' || $user === 'pma' || $user === '') {
                continue;
            }

            $userPermission = $this->checkPrivileges($users[$i]);
            if ($grand === 'Y') {
                $userScript = str_replace('\\', '', "GRANT $userPermission ON *.* TO '$user'@'$host' IDENTIFIED BY PASSWORD '$password' WITH GRANT OPTION;");
            } else {
                $userScript = str_replace('\\', '', "GRANT $userPermission ON *.* TO '$user'@'$host' IDENTIFIED BY PASSWORD '$password';");
            }
            $userScript .= "$userScript\n\n";

            $sql = "select * from mysql.db WHERE Host = '$host' AND User = '$user';";
            $result = $this->con->query($sql);

            $database = [];
            while ($fetch = $result->fetch(PDO::FETCH_ASSOC)) {
                $database[] = $fetch;
            }

            $databaseScript = '';
            for ($n = 0; $n < count($database); $n++) {
                $databaeName = $database[$n]['Db'];
                $dbGrand = $users[$i]['Grant_priv'];

                $databasePermission = $this->checkPrivileges($database[$n]);
                if ($dbGrand === 'Y') {
                    $databaseScript .= str_replace('\\', '', "GRANT $databasePermission ON `$databaeName`.* TO '$user'@'$host' WITH GRANT OPTION;");
                } else {
                    $databaseScript .= str_replace('\\', '', "GRANT $databasePermission ON `$databaeName`.* TO '$user'@'$host';");
                }

                $databaseScript .= "$databaseScript\n\n";
            }

            $script .= "$userScript" . "$databaseScript\n\n\n";
        }

        $file = $this->backupDirectory . 'users-' . date("Y-m-d_H-i", time()) . '.sql';
        $this->saveBackupFile($script, $file);

        return $file;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  PUBLIC FUNCTION FOR ARRAY OPERATIONS  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Searching in arrays inside array and return the ID of main array.
     * @param array $array <br> The array will searching inside it. <p></p>
     * @param string $key <br> The key name of element in array we want seraching for. <p></p>
     * @param string $value <br> The value will search it. <p></p>
     * @return int on found <br> <b>ID</b> number of main array contain this key and value <p></p>.
     * @return bool on not found <br> <b>false</b> Number of main array contain this key and value <p></p>.
     */
    public function searchInsideArray($array, $key, $value) {
        $id = 0;
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                $finde = searchInsideArray($v, $key, $value);
                if ($finde !== false) {
                    return $id;
                }
            } else {
                if ($k === $key && $v === $value) {
                    return $id;
                }
            }

            $id++;
        }
        return false;
    }

    /**
     * Delete specific element form array using the element id.
     * @param array $array <br> The array we want remove element from it. <p></p>
     * @param int $removId <br> The id will removed. <p></p>
     * @return array <br> The same array after remove element.
     */
    public function unSetArray($array, $removId) {
        if ($removId < 0 || $removId >= count($array)) {
            return $array;
        }
        $array = array_merge(array_slice($array, 0, $removId), array_slice($array, $removId + 1));
        return $array;
    }

    /**
     * Change array element value.
     * @param array $array <br> The array we want remove element from it. <p></p>
     * @param string $naewValue <br> The new value will give to element. <p></p>
     * @param int $swapId <br> The id will changed value. <p></p>
     * @return array <br> The same array after remove element.
     */
    public function swapArray($array, $naewValue, $swapId) {
        $array = array_merge(array_slice($array, 0, $swapId), $naewValue, array_slice($array, $swapId + 1));
        return $array;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  PUBLIC FUNCTION FRO DATE & TIME  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Get the timestamp of specific date time or current date time.
     * @param string $date <br> The date time formated 'Y-m-d H:i' or '0' to get current timestamp. <p></p>
     * @return int <br> The time stamp of date time.
     */
    public function getTimeStamp($date = '0') {
        if ($date !== '0') {
            return strtotime($date) + 7200;
        } else {
            $dt = new DateTime();
            return ((int) $dt->getTimestamp() + 7200);
        }
    }

    /**
     * Get the date from timestamp.
     * @param int $timeStamp <br> The timestamp value. <p></p>
     * @return string <br> The date in format 'Y-m-d'.
     */
    public function getDateFromTimeStamp($timeStamp) {
        return gmdate("Y-m-d", $timeStamp);
    }

    /**
     * Get the date time from timestamp.
     * @param int $timeStamp <br> The timestamp value. <p></p>
     * @return string <br> The date time in format 'Y-m-d H:i'.
     */
    public function getDateTimeFromTimeStamp($timeStamp) {
        return gmdate("Y-m-d H:i", $timeStamp);
    }

    /**
     * Add positive or negative number of days to timestamp.
     * @param int $timeStamp <br> The timestamp value. <p></p>
     * @param int $daysNo <br> Positive or negative number of days to add to sum to timestamp. <p></p>
     * @return int <br> The new timestamp after adding value.
     */
    public function addDayesToTimeStamp($timeStamp, $daysNo) {
        $total = $timeStamp + ($daysNo * 86400);
        return $total;
    }

    /**
     * Get time duration string formated in 'H:i:s' from number of seconds.
     * @param int $second <br> The number of seconds. <p></p>
     * @return string <br> The time duration in format 'H:i:s'.
     */
    public function getTimeFormat($second) {
        $hour = (string) floor($second / 3600);
        if ((int) $hour > 0) {
            $second = $second - ($hour * 3600);
        }
        $minute = (string) floor($second / 60);
        $second = (string) $second % 60;
        if (count($minute) === 1) {
            $minute = '0' + $minute;
        }
        if (count($second) === 1) {
            $second = '0' + $second;
        }
        $formatedTime = "$hour:$minute:$second";

        return $formatedTime;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*  PRIVATE FUNCTION NEEDED IN CLASS  *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */
    /* -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*- */

    /**
     * Generate 13 characters id using real timestamp and random function.
     * @return string 13 characters unique id.
     */
    private function get_id() {
        $char = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        $currentDate = date_create();
        $writeDate = date_timestamp_get($currentDate);
        $id = $char[mt_rand(0, 25)] . $char[mt_rand(0, 25)] . substr($writeDate, 0, 6) . $char[mt_rand(0, 25)] . substr($writeDate, 6, 4);
        return $id;
    }

    /**
     * Get fields string from array to use in select function.
     * @param array $fields <br> The array contain fields name. <p></p>
     * @return string <br> contain fields '`field1`, `field2`, ...' or '*' if array is .
     */
    private function getFields($fields) {
        $data = '';
        if (count($fields) !== 0 && $fields !== '') {
            for ($i = 0; $i < count($fields); $i++) {
                $data .= '`' . $fields[$i] . '`' . ', ';
            }
            $data = substr($data, 0, strlen($data) - 2);
        } else {
            $data = '*';
        }
        return $data;
    }

    /**
     * Generate WHERE string fore SQL statement to use in another function in this class.
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @return string <br> contain WHERE string like '`field1` = :value1 AND `field2` = value2 AND ...'.
     */
    private function getWhereValue($where, $nextCondetion = 'AND') {
        $condition = '';

        if (is_array($where) && count($where) > 0) {
            $max = count($where) - 1;
            for ($i = 0; $i < count($where); $i++) {
                if (isset($where[$i]['field'])) {
                    $field = $where[$i]['field'];
                } elseif (isset($where[$i]['f'])) {
                    $field = $where[$i]['f'];
                } else {
                    $field = '';
                }
                if (isset($where[$i]['operation'])) {
                    $operation = $where[$i]['operation'];
                } elseif (isset($where[$i]['o'])) {
                    $operation = $where[$i]['o'];
                } else {
                    $operation = '';
                }

                if ($field !== '' && $operation !== '') {
                    $condition .= "`$field` $operation :$field";
                    if ($i < $max && is_array($nextCondetion) && count($nextCondetion) === count($where) - 1 && $nextCondetion[$i] !== '') {
                        $next = strtoupper($nextCondetion[$i]);
                        if ($next !== 'AND' && $next !== 'OR') {
                            $next = 'AND';
                        }
                        $condition .= " $next ";
                    } elseif ($i < $max && $nextCondetion === 'OR' || $nextCondetion === 'or') {
                        $condition .= ' OR ';
                    } elseif ($i < $max) {
                        $condition .= ' AND ';
                    }
                }
            }
        }

        if ($condition !== '') {
            $condition = "WHERE $condition";
        }

        return $condition;
    }

    /**
     * Compose string have fields and values parameter in PDO formate to escape SQL injection and special characters to can use safety in SQL statement.
     * @param array $fields <br> The associative array contain fields name and values <br>  ['field1' => value1, 'field2' => value2, ...]. <p></p>
     * @return string <br> contain fields and values in PDE format.
     */
    private function setFields($fields) {
        $operation = '';
        if (is_array($fields)) {
            foreach ($fields as $field => $value) {
                $operation .= "`$field` = :$field, ";
            }

            $operation = substr($operation, 0, strlen($operation) - 2);
        }

        return $operation;
    }

    /**
     * Link parameters with value in PDO to escape SQL injection and special characters to can use safety in SQL statement.
     * @param string $sql <br> The SQL statement with parameters. <p></p>
     * @param array $data <br> The associative array contain values in order. <p></p>
     * @return null return value but change the parameter $sql.
     */
    private function setFieldsValue(&$sql, $data) {
        $keys = array_keys($data);
        $values = array_values($data);
        for ($i = 0; $i < count($keys); $i++) {
            $sql->bindParam(':' . $keys[$i], $values[$i]);
        }
    }

    /**
     * Link parameters with value in PDO to escape SQL injection and special characters to can use safety in SQL statement.
     * @param string $sql <br> The SQL statement with parameters. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['f' => 'field1', 'o' => '=', 'v' => 'test'], ['f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @return null return value but change the parameter $sql.
     */
    private function setWhereValues(&$sql, $where) {
        for ($i = 0; $i < count($where); $i++) {
            if (isset($where[$i]['field'])) {
                $field = $where[$i]['field'];
            } elseif (isset($where[$i]['f'])) {
                $field = $where[$i]['f'];
            } else {
                $field = '';
            }
            if (isset($where[$i]['value'])) {
                $value = $where[$i]['value'];
            } elseif (isset($where[$i]['v'])) {
                $value = $where[$i]['v'];
            } else {
                $value = false;
            }

            if ($field !== '' && $value !== false) {
                $sql->bindParam(':' . $field, $value);
            }
        }
    }

    /**
     * Create field text to us in createTable function.
     * @param array $fieldData <br> The associative array contain fields data. <br> <b>like</b> [['name' => 'field_name', 'type' => MySQL_DB::TYPE_INT, 'length' => 10, 'default' => MySQL_DB::DEFAULT_NOT_NULL, 'attributes' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'comment' => 'test field'], ...]. <br> <b>Or</b> [['n' => 'field_name', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'test field'], ...]. <p></p>
     * @param string $primaryKeyName <br> The primary key field name. <p></p>
     * @param bool $autoIncrementId <br> The primary key field auto increment or not. <p></p>
     * @return string contain field data.
     */
    private function getCreateTableField($fieldData, $primaryKeyName, $autoIncrementId) {
        $availableTypes = [self::TYPE_BIGINT, self::TYPE_BOOLEAN, self::TYPE_CHAR, self::TYPE_DATE, self::TYPE_DATETIME,
            self::TYPE_DECIMAL, self::TYPE_DOUBLE, self::TYPE_FLOAT, self::TYPE_INT, self::TYPE_LONGTEXT,
            self::TYPE_MEDIUMINT, self::TYPE_MEDIUMTEXT, self::TYPE_REAL, self::TYPE_SERIAL, self::TYPE_SMALINT,
            self::TYPE_TEXT, self::TYPE_TIME, self::TYPE_TIMESTAMP, self::TYPE_TINYINT, self::TYPE_VARCHAR, self::TYPE_YEAR];
        $availableAttributes = [self::ATTRIBUTES_UNSIGNED, self::ATTRIBUTES_UNSIGNED_ZEROFILL, self::ATTRIBUTES_ON_UPDATE_CURRENT_TIMESTAMP];

        if (isset($fieldData['name'])) {
            $name = trim($fieldData['name']);
        } elseif (isset($fieldData['n'])) {
            $name = trim($fieldData['n']);
        } else {
            $name = '';
        }
        if (isset($fieldData['type'])) {
            $type = strtoupper(trim($fieldData['type']));
        } elseif (isset($fieldData['t'])) {
            $type = strtoupper(trim($fieldData['t']));
        } else {
            $type = '';
        }
        if (isset($fieldData['length'])) {
            $length = (int) $fieldData['length'];
        } elseif (isset($fieldData['l'])) {
            $length = (int) $fieldData['l'];
        } else {
            $length = 0;
        }
        if (isset($fieldData['default'])) {
            if (trim($fieldData['default'] === '')) {
                $default = 'NOT NULL';
            } else {
                $default = $fieldData['default'];
            }
        } elseif (isset($fieldData['d']) && $fieldData['d'] === '') {
            if (trim($fieldData['d'] === '')) {
                $default = 'NOT NULL';
            } else {
                $default = $fieldData['d'];
            }
        } elseif (!isset($fieldData['default']) && !isset($fieldData['d'])) {
            $default = 'NOT NULL';
        }
        if (isset($fieldData['attributes'])) {
            $attributes = strtoupper(trim($fieldData['attributes']));
            if (!in_array($attributes, $availableAttributes)) {
                $attributes = '';
            }
        } elseif (isset($fieldData['a'])) {
            $attributes = strtoupper(trim($fieldData['a']));
            if (!in_array($attributes, $availableAttributes)) {
                $attributes = '';
            }
        } else {
            $attributes = '';
        }
        if (isset($fieldData['comment'])) {
            $comment = trim($fieldData['comment']);
        } elseif (isset($fieldData['c'])) {
            $comment = trim($fieldData['c']);
        } else {
            $comment = '';
        }

        if ($name === '' || $type === '' || !in_array($type, $availableTypes)) {
            return '';
        }

        $field = "`$name` $type";
        if ($length > 0) {
            $field .= "($length)";
        }
        if ($attributes !== '') {
            $field .= " $attributes";
        }
        if ($name === $primaryKeyName) {
            if ($autoIncrementId) {
                $field .= " NOT NULL AUTO_INCREMENT";
            } else {
                $field .= " NOT NULL";
            }
        } else {
            if ($default !== '') {
                $field .= " $default";
            }
        }
        if ($comment !== '') {
            $field .= " COMMENT '$comment', ";
        } else {
            $field .= ", ";
        }

        return $field;
    }

    /**
     * Create field text to us in creatView function.
     * @param array $viewFields <br> The associative array contain fields data. <br> <b>like</b> [['table' => 'table_name', 'column' => 'column_name', 'name' => 'new_name'], ...]. <br> <b>Or</b> [['t' => 'table_name', 'c' => 'column_name', 'n' => 'new_name'], ...]. <br> If not set the name of array will use same column name. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return string contain field data.
     */
    private function getViewField($viewFields, $databaseName = '') {
        $fields = '';
        for ($i = 0; $i < count($viewFields); $i++) {
            if (isset($viewFields[$i]['table'])) {
                $table = trim($viewFields[$i]['table']);
            } elseif (isset($viewFields[$i]['t'])) {
                $table = trim($viewFields[$i]['t']);
            } else {
                $table = '';
            }
            if (isset($viewFields[$i]['column'])) {
                $column = trim($viewFields[$i]['column']);
            } elseif (isset($viewFields[$i]['c'])) {
                $column = trim($viewFields[$i]['c']);
            } else {
                $column = '';
            }
            if (isset($viewFields[$i]['name'])) {
                $name = trim($viewFields[$i]['name']);
            } elseif (isset($viewFields[$i]['n'])) {
                $name = trim($viewFields[$i]['n']);
            } else {
                $name = '';
            }
            if ($name === '') {
                $name = $column;
            }

            if ($table !== '' && $column !== '' && $databaseName !== '') {
                $fields .= "`$databaseName`.`$table`.`$column` AS `$name`, ";
            } elseif ($table !== '' && $column !== '') {
                $fields .= "`$table`.`$column` AS `$name`, ";
            }
        }

        if (strlen($fields) > 2) {
            $fields = substr($fields, 0, strlen($fields) - 2);
            return $fields;
        } else {
            return '';
        }
    }

    /**
     * Create field text to us in creatView function.
     * @param string $linkedColumn <br> The associative array contain table column will related from it. <br> <b>Like</b> [['table1' => 'name', 'column1' => 'name', 'table2' => 'name', 'column2' => 'name'], ...]. <br> <b>or</b> [['t1' => 'name', 'c1' => 'name', 't2' => 'name', 'c2' => 'name'], ...] <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return string contain field data.
     */
    private function getViewLinked($linkedColumn, $databaseName) {
        $fields = '';
        $linked = [];
        for ($i = 0; $i < count($linkedColumn); $i++) {
            if (isset($linkedColumn[$i]['table1'])) {
                $table1 = trim($linkedColumn[$i]['table1']);
            } elseif (isset($linkedColumn[$i]['t1'])) {
                $table1 = trim($linkedColumn[$i]['t1']);
            } else {
                $table1 = '';
            }
            if (isset($linkedColumn[$i]['column1'])) {
                $column1 = trim($linkedColumn[$i]['column1']);
            } elseif (isset($linkedColumn[$i]['c1'])) {
                $column1 = trim($linkedColumn[$i]['c1']);
            } else {
                $column1 = '';
            }
            if (isset($linkedColumn[$i]['table2'])) {
                $table2 = trim($linkedColumn[$i]['table2']);
            } elseif (isset($linkedColumn[$i]['t2'])) {
                $table2 = trim($linkedColumn[$i]['t2']);
            } else {
                $table2 = '';
            }
            if (isset($linkedColumn[$i]['column2'])) {
                $column2 = trim($linkedColumn[$i]['column2']);
            } elseif (isset($linkedColumn[$i]['c2'])) {
                $column2 = trim($linkedColumn[$i]['c2']);
            } else {
                $column2 = '';
            }

            if ($table1 !== '' && $table2 !== '' && $column1 !== '' && $column2 !== '' && $databaseName !== '') {
                $fields .= "(`$databaseName`.`$table1`.`$column1` = `$databaseName`.`$table2`.`$column2`) AND ";
                $linked[] = "(`$databaseName`.`$table1` join `$databaseName`.`$table2`)";
            } elseif ($table1 !== '' && $table2 !== '' && $column1 !== '' && $column2 !== '') {
                $fields .= "(`$table1`.`$column1` = `$table2`.`$column2`) AND ";
                $linked[] = "(`$table1` join `$table2`)";
            }
        }

        $linked = array_unique($linked);
        $linkedString = $linked[0];
        for ($i = 1; $i < count($linked); $i++) {
            $linkedString .= " AND $linked[$i]";
        }

        if (strlen($fields) > 5 && $linkedString !== 0) {
            $fields = substr($fields, 0, strlen($fields) - 5);
            return ['table' => $linkedString, 'linked' => $fields];
        } else {
            return ['table' => '', 'linked' => ''];
        }
    }

    /**
     * Create where condition for view to us in creatView function.
     * @param string $linked <br> The linked table string. <p></p>
     * @param array $where <br> The associative array contain field name, operation and Value. <br> Like [['table' => 'table_name', 'field' => 'field1', 'operation' => '=', 'value' => 'test'],  ...]. <br> Or [['t' => 'table_name', 'f' => 'field1', 'o' => '=', 'v' => 'test'], ['t' => 'table_name', 'f' => 'field2', 'o' => '<=', 'v' => 1], ...]. <p></p>
     * @param string $nextCondetion [optional] <br> The sequence in where condition <br> <b>'AND'</b> the default value <br> Available values 'AND', 'OR' and array less than $where array by 1,  . <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return string <br> contain WHERE string like '`field1` = :value1 AND `field2` = value2 AND ...'.
     */
    private function getViewWhere($linked, $where, $nextCondetion = 'AND', $databaseName = '') {
        $condition = '';

        if (is_array($where) && count($where) > 0) {
            $max = count($where) - 1;
            for ($i = 0; $i < count($where); $i++) {
                if (isset($where[$i]['table'])) {
                    $table = $where[$i]['table'];
                } elseif (isset($where[$i]['t'])) {
                    $table = $where[$i]['t'];
                } else {
                    $table = false;
                }
                if (isset($where[$i]['field'])) {
                    $field = $where[$i]['field'];
                } elseif (isset($where[$i]['f'])) {
                    $field = $where[$i]['f'];
                } else {
                    $field = false;
                }
                if (isset($where[$i]['operation'])) {
                    $operation = $where[$i]['operation'];
                } elseif (isset($where[$i]['o'])) {
                    $operation = $where[$i]['o'];
                } else {
                    $operation = false;
                }
                if (isset($where[$i]['value'])) {
                    $value = $where[$i]['value'];
                } elseif (isset($where[$i]['v'])) {
                    $value = $where[$i]['v'];
                } else {
                    $value = false;
                }

                if ($table !== false && $field !== false && $operation !== false && $value !== false && $databaseName !== '') {
                    $condition .= "(`$databaseName`.`$table`.`$field` $operation '$value')";
                } elseif ($table !== false && $field !== false && $operation !== false && $value !== false) {
                    $condition .= "(`$table`.`$field` $operation '$value')";
                }

                if ($table && $field && $operation && $value) {
                    if ($i < $max && is_array($nextCondetion) && count($nextCondetion) === count($where) - 1 && $nextCondetion[$i] !== '') {
                        $next = strtoupper($nextCondetion[$i]);
                        if ($next !== 'AND' && $next !== 'OR') {
                            $next = 'AND';
                        }
                        $condition .= " $next ";
                    } elseif ($i < $max && $nextCondetion === 'OR' || $nextCondetion === 'or') {
                        $condition .= ' OR ';
                    } elseif ($i < $max) {
                        $condition .= ' AND ';
                    }
                }
            }
        }

        if ($condition !== '') {
            $condition = "WHERE ($linked AND $condition)";
        } else {
            $condition = "WHERE $linked";
        }

        return $condition;
    }

    /**
     * Create field text to us in addTableColumn function.
     * @param array $fieldData <br> The associative array contain fields data. <br> <b>like</b> [['name' => 'field_name', 'type' => MySQL_DB::TYPE_INT, 'length' => 10, 'default' => MySQL_DB::DEFAULT_NOT_NULL, 'attributes' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'comment' => 'test field'], ...]. <br> <b>Or</b> [['n' => 'field_name', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'test field'], ...]. <p></p>
     * @param string $fieldAfter <br> The name of field will add new fields after it. <p></p>
     * @return string contain field data.
     */
    private function getAddTableField($fieldData, $fieldAfter) {
        if (trim($fieldAfter) === '') {
            return '';
        }

        $availableTypes = [self::TYPE_BIGINT, self::TYPE_BOOLEAN, self::TYPE_CHAR, self::TYPE_DATE, self::TYPE_DATETIME,
            self::TYPE_DECIMAL, self::TYPE_DOUBLE, self::TYPE_FLOAT, self::TYPE_INT, self::TYPE_LONGTEXT,
            self::TYPE_MEDIUMINT, self::TYPE_MEDIUMTEXT, self::TYPE_REAL, self::TYPE_SERIAL, self::TYPE_SMALINT,
            self::TYPE_TEXT, self::TYPE_TIME, self::TYPE_TIMESTAMP, self::TYPE_TINYINT, self::TYPE_VARCHAR, self::TYPE_YEAR];
        $availableAttributes = [self::ATTRIBUTES_UNSIGNED, self::ATTRIBUTES_UNSIGNED_ZEROFILL, self::ATTRIBUTES_ON_UPDATE_CURRENT_TIMESTAMP];

        if (isset($fieldData['name'])) {
            $name = trim($fieldData['name']);
        } elseif (isset($fieldData['n'])) {
            $name = trim($fieldData['n']);
        } else {
            $name = '';
        }
        if (isset($fieldData['type'])) {
            $type = strtoupper(trim($fieldData['type']));
        } elseif (isset($fieldData['t'])) {
            $type = strtoupper(trim($fieldData['t']));
        } else {
            $type = '';
        }
        if (isset($fieldData['length'])) {
            $length = (int) $fieldData['length'];
        } elseif (isset($fieldData['l'])) {
            $length = (int) $fieldData['l'];
        } else {
            $length = 0;
        }
        if (isset($fieldData['default'])) {
            if (trim($fieldData['default'] === '')) {
                $default = 'NOT NULL';
            } else {
                $default = $fieldData['default'];
            }
        } elseif (isset($fieldData['d']) && $fieldData['d'] === '') {
            if (trim($fieldData['d'] === '')) {
                $default = 'NOT NULL';
            } else {
                $default = $fieldData['d'];
            }
        } elseif (!isset($fieldData['default']) && !isset($fieldData['d'])) {
            $default = 'NOT NULL';
        }
        if (isset($fieldData['attributes'])) {
            $attributes = strtoupper(trim($fieldData['attributes']));
            if (!in_array($attributes, $availableAttributes)) {
                $attributes = '';
            }
        } elseif (isset($fieldData['a'])) {
            $attributes = strtoupper(trim($fieldData['a']));
            if (!in_array($attributes, $availableAttributes)) {
                $attributes = '';
            }
        } else {
            $attributes = '';
        }
        if (isset($fieldData['comment'])) {
            $comment = trim($fieldData['comment']);
        } elseif (isset($fieldData['c'])) {
            $comment = trim($fieldData['c']);
        } else {
            $comment = '';
        }

        if ($name === '' || $type === '' || !in_array($type, $availableTypes)) {
            return '';
        }

        $field = "`$name` $type";
        if ($length > 0) {
            $field .= "($length)";
        }
        if ($attributes !== '') {
            $field .= " $attributes";
        }
        if ($default !== '') {
            $field .= " $default";
        }
        if ($comment !== '') {
            $field .= " COMMENT '$comment'";
        }
        $field .= " AFTER `$fieldAfter`, ";

        return $field;
    }

    /**
     * Check table if exist and drop it or return false.
     * @param string $tableName <br> The table name. <p></p>
     * @param bool $dropOldTable <br> <b>true</b> drop table if exists, <b>false</b> don't drop table and don't create table if exists. <p></p>
     * @param string $databaseName [optional] <br> The name of database containing this table if don't send or send empty value will use the database in connection. <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    private function dropTableIfExist($tableName, $dropOldTable, $databaseName = '') {
        $tables = $this->getDatabaseTables($databaseName);
        $views = $this->getDatabaseViews($databaseName);
        $tableSQL = '';
        if (in_array($tableName, $tables) && $dropOldTable === true) {
            if ($dropOldTable) {
                if (trim($databaseName) !== '') {
                    $tableSQL = "DROP TABLE `$databaseName`.`$tableName`; COMMIT;";
                } else {
                    $tableSQL = "DROP TABLE `$tableName`; COMMIT;";
                }
            } else {
                return false;
            }
        }
        if ($tableSQL !== '') {
            $sql = $this->con->prepare($tableSQL);
            if ($sql->execute() === false) {
                return false;
            }
        }

        $viewSQL = '';
        if (in_array($tableName, $views) && $dropOldTable === true) {
            if ($dropOldTable) {
                if (trim($databaseName) !== '') {
                    $viewSQL = "DROP VIEW `$databaseName`.`$tableName`;";
                } else {
                    $viewSQL = "DROP VIEW `$tableName`;";
                }
            } else {
                return false;
            }
        }
        if ($viewSQL !== '') {
            $sql = $this->con->prepare($viewSQL);
            if ($sql->execute() === false) {
                return false;
            }
        }

        return true;
    }

    /**
     * private save SQL statements in text file.
     * @param string $sql <br> The SQL statements <p></p>
     * @param string $fileName <br> The file name <p></p>
     * @return bool <b>true</b> on success or <b>false</b> on failure.
     */
    private function saveBackupFile($sql, $fileName) {
        if (!is_dir($this->backupDirectory)) {
            mkdir($this->backupDirectory, 0777, true);
        }

        file_put_contents($fileName, $sql, FILE_APPEND | LOCK_EX);

        return true;
    }

    /**
     * Backup all MySQL users.
     * @param array $privileges <br> The array contain the user permissions com from mysql database. <p></p>
     * @return string <b>File name</b> on success or <b>false</b> on failure.
     */
    private function checkPrivileges($privileges) {
        $permission = '';
        if (isset($privileges['Select_priv']) && $privileges['Select_priv'] === 'Y') {
            $permission .= self::PERMISSION_SELECT . ', ';
        }
        if (isset($privileges['Insert_priv']) && $privileges['Insert_priv'] === 'Y') {
            $permission .= self::PERMISSION_INSERT . ', ';
        }
        if (isset($privileges['Update_priv']) && $privileges['Update_priv'] === 'Y') {
            $permission .= self::PERMISSION_UPDATE . ', ';
        }
        if (isset($privileges['Delete_priv']) && $privileges['Delete_priv'] === 'Y') {
            $permission .= self::PERMISSION_DELETE . ', ';
        }
        if (isset($privileges['Create_priv']) && $privileges['Create_priv'] === 'Y') {
            $permission .= self::PERMISSION_CREATE . ', ';
        }
        if (isset($privileges['Index_priv']) && $privileges['Index_priv'] === 'Y') {
            $permission .= self::PERMISSION_INDEX . ', ';
        }
        if (isset($privileges['Alter_priv']) && $privileges['Alter_priv'] === 'Y') {
            $permission .= self::PERMISSION_ALTER . ', ';
        }
        if (isset($privileges['Lock_tables_priv']) && $privileges['Lock_tables_priv'] === 'Y') {
            $permission .= self::PERMISSION_LOCK_TABLES . ', ';
        }
        if (isset($privileges['Create_view_priv']) && $privileges['Create_view_priv'] === 'Y') {
            $permission .= self::PERMISSION_CREATE_VIEW . ', ';
        }
        if (isset($privileges['Create_routine_priv']) && $privileges['Create_routine_priv'] === 'Y') {
            $permission .= self::PERMISSION_CREATE_ROUTINE . ', ';
        }
        if (isset($privileges['Alter_routine_priv']) && $privileges['Alter_routine_priv'] === 'Y') {
            $permission .= self::PERMISSION_ALTER_ROUTINE . ', ';
        }
        if (isset($privileges['Execute_priv']) && $privileges['Execute_priv'] === 'Y') {
            $permission .= self::PERMISSION_EXECUTE . ', ';
        }
        if (isset($privileges['Select_priv']) && $privileges['Select_priv'] === 'Y') {
            $permission .= self::PERMISSION_SELECT . ', ';
        }
        if (isset($privileges['Trigger_priv']) && $privileges['Trigger_priv'] === 'Y') {
            $permission .= self::PERMISSION_TRIGGER . ', ';
        }
        if (isset($privileges['File_priv']) && $privileges['File_priv'] === 'Y') {
            $permission .= self::PERMISSION_FILE . ', ';
        }
        if (isset($privileges['Show_db_priv']) && $privileges['Show_db_priv'] === 'Y') {
            $permission .= self::PERMISSION_SHOW_DATABASES . ', ';
        }
        if (isset($privileges['Super_priv']) && $privileges['Super_priv'] === 'Y') {
            $permission .= self::PERMISSION_SUPER . ', ';
        }
        if (isset($privileges['Create_user_priv']) && $privileges['Create_user_priv'] === 'Y') {
            $permission .= self::PERMISSION_CREATE_USER . ', ';
        }

        if (strlen($permission) > 2) {
            $permission = substr($permission, 0, strlen($permission) - 2);
        }

        return $permission;
    }

}
