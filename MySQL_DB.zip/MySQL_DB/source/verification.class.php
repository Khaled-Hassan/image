<?php

/**
 * Filter data get from user and chck it if compatible with fields length, format and scape SQL injection <b>using regular_expression</b>.<p></p>
 * @author Khaled Hassan
 * @category Security
 * @link khaled.h.developer@gmail.com
 */
class verification {

    /**
     * Check string if it's in Email format or not.
     * @param string $value <br> The Email want check its format. <p></p>
     * @return string <b>Email</b> on success or <b>FALSE</b> on failure.
     */
    public function isEmail($value) {
        $value = trim(urldecode($value));
        $test = preg_match('/^[a-zA-Z0-9][a-zA-Z0-9\._-]+@[a-zA-Z0-9_-]+\.[a-zA-Z]{2,4}([\.][a-zA-Z]{2})?$/', $value);
        if ($test === 1) {
            $value = $this->escapeString($value);
            return $value;
        } elseif ($test === 0) {
            return FALSE;
        }
    }

    /**
     * Check string if it's in website format or not.
     * @param string $value <br> The website want check its format. <p></p>
     * @return string <b>Website</b> on success or <b>FALSE</b> on failure.
     */
    public function isWebsite($value) {
        $value = trim(urldecode($value));
        if (substr($value, 0, 11) !== 'http://www.') {
            if (substr($value, 0, 7) === 'http://') {
                $value = 'http://www.' . substr($value, 7);
            } elseif (substr($value, 0, 4) === 'www.') {
                $value = 'http://www.' . substr($value, 4);
            } else {
                $value = 'http://www.' . $value;
            }
        }
        $test = preg_match('/^http:\/\/www\.[a-zA-Z0-9_\.]+\.[a-zA-Z]{2,12}[\.]?[a-zA-Z]?[a-zA-Z]?$/', $value);
        if ($test === 1) {
            $value = $this->escapeString($value);
            return $value;
        } elseif ($test === 0) {
            return FALSE;
        }
    }

    /**
     * Check string if it's in IP address format or not.
     * @param string $value <br> The IP address want check its format. <p></p>
     * @return string <b>IP address</b> on success or <b>FALSE</b> on failure.
     */
    public function isIP($value) {
        $value = trim(urldecode($value));
        if (strlen($value) <= 15) {
            $test = preg_match('/^(\d|[01]?\d\d|2[0-4]\d|25[0-5])\.(\d|[01]?\d\d|2[0-4]\d|25[0-5])\.(\d|[01]?\d\d|2[0-4]\d|25[0-5])\.(\d|[01]?\d\d|2[0-4]\d|25[0-5])$/', $value);
            if ($test === 1) {
                $value = $this->escapeString($value);
                return $value;
            } elseif ($test === 0) {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in telephone number format or not.
     * @param string $value <br> The telephone number want check its format. <p></p>
     * @param bool $locale <br> <b>TRUR</b> the number in locale area format <b>FALSE</b> the number in international format ex +20 000. <p></p>
     * @return string <b>telephone number</b> on success or <b>FALSE</b> on failure.
     */
    public function isTel($value, $locale = FALSE) {
        $value = trim($value);
        if (strlen($value) <= 16) {
            if ($locale === TRUE) {
                if (is_numeric($value)) {
                    $test = preg_match('/^[0][0-9]{6,12}$/', $value);
                    if ($test === 0) {
                        return FALSE;
                    }
                } else {
                    return FALSE;
                }
            } elseif ($locale === FALSE) {
                $test = preg_match('/^([0]|[00]|[+]?[1-9]?[0-9]{8,13})$/', $value);
                if ($test === 0) {
                    return FALSE;
                }
            }

            return $value;
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in password format have characters and (number or special characters) or not.
     * @param string $value <br> The password want check its format. <p></p>
     * @param string $anotherData <br> oprional if want concatenate anther data like Email with password to complicate hashing. <p></p>
     * @param int $minLength <br> The minimum length allowed in password <b>using if passwword not hashed</b>. <p></p>
     * @param bool $hashed <br> <b>TRUR</b> the password hashed (64 characters) <b>FALSE</b> the password is normal string. <p></p>
     * @return string <b>Hashed password</b> on success or <b>FALSE</b> on failure.
     */
    public function isPassword($value, $anotherData = '', $minLength = 0, $hashed = TRUE) {
        $value = trim(urldecode($value));
        if ($anotherData !== '') {
            $value .= $anotherData;
        }
        if ($hashed === TRUE) {
            if (strlen($value) === 64 || strlen($value) === 40) {
                $value = hash("sha256", $value);
                $value = $this->escapeString($value);
                return $value;
            } else {
                return FALSE;
            }
        } else {
            if (strlen($value) >= $minLength) {
                $value = $this->escapeString($value);
                $test1 = preg_match('/^[a-zA-Z0-9\$#@!\.\*_-]{6,14}$/', $value);
                $test2 = preg_match('/[\$#@\._-]{1,}/', $value);
                if ($test1 === 1 || $test2 === 1) {
                    $value = hash("sha256", $value);
                    return $value;
                } else {
                    return FALSE;
                }
            } else {
                return FALSE;
            }
        }
    }

    /**
     * Check string if it's in number format <b>(integer or floot)</b> or not.
     * @param string $value <br> The number want check its format. <p></p>
     * @param bool $haveDecimal <br> <b>TRUR</b> the number is floot <b>FALSE</b> the number is integer. <p></p>
     * @return int <b>number</b> on success or <b>FALSE</b> on failure.
     * @return floot <b>number</b> on success or <b>FALSE</b> on failure.
     */
    public function isNumeric($value, $haveDecimal = FALSE) {
        $value = trim(urldecode($value));
        $value = $this->escapeString($value);
        if (is_numeric($value)) {
            $value = ($value == (int) $value) ? (int) $value : (double) $value;
            if ($haveDecimal === FALSE) {
                $value = (int) $value;
            }
            return $value;
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in safe databse format or not.
     * @param string $value <br> The string want check its format. <p></p>
     * @param int $max <br> The maximum length of characters. <p></p>
     * @param int $min <br> The minimum length of characters. <p></p>
     * @return string <b>String</b> after escape special characters to safe database on success or <b>FALSE</b> on failure.
     */
    public function isString($value, $max = 0, $min = 0) {
        $value = trim(urldecode($value));
        if ($min !== 0) {
            if (strlen($value) < $min) {
                return FALSE;
            }
        }
        if ($max !== 0) {
            if (strlen($value) > $max) {
                return FALSE;
            }
        }
        $value = $this->escapeString($value);
        return $value;
    }

    /**
     * Check string if it's in wanted format or not but don't encode character to can read arbic, <b> Can use when save data in files like articles.
     * @param string $value <br> The string want check its format. <p></p>
     * @param int $max <br> The maximum length of characters. <p></p>
     * @param int $min <br> The minimum length of characters. <p></p>
     * @return string <b>String</b> after escape special characters to safe database on success or <b>FALSE</b> on failure.
     */
    public function isNormalString($value, $max = 0, $min = 0) {
        $value = trim(urldecode($value));
        if ($min !== 0) {
            if (strlen($value) < $min) {
                return FALSE;
            }
        }
        if ($max !== 0) {
            if (strlen($value) > $max) {
                return FALSE;
            }
        }
        $value = htmlentities($value);
        $value = preg_replace_callback('/\\\\u(\w{4})/', function ($matches) {
            return html_entity_decode('&#x' . $matches[1] . ';', ENT_COMPAT, 'UTF-8');
        }, $value);
        return $value;
    }

    /**
     * Encode HTML string and escape special character like tags "<>" and slash "/" to can save safely in database.
     * @param string $value <br> The HTML string want encode it. <p></p>
     * @return string <b>HTML</b> after encode it.
     */
    public function isHTML($value) {
        $value = urldecode($value);
        $value = $this->escapeString($value);
        return $value;
    }

    /**
     * Decode HTML string to tags to can show in browser.
     * @param string $value <br> The string want decode it to HTML. <p></p>
     * @return string <b>HTML</b> after decode it.
     */
    public function getHTML($value) {
        $value = stripslashes($value);
        return $value;
    }

    /**
     * Check number if it's in mony format or not.
     * @param string $value <br> The string want check its format. <p></p>
     * @return int <b>duble</b> on success or <b>FALSE</b> on failure.
     */
    public function isMony($value) {
        $value = trim(urldecode($value));
        $value = $this->escapeString($value);
        if (is_numeric($value)) {
            $test = preg_match('/^[0-9]+([\.]?[0-9]{1,2})?$/', $value);
            if ($test === 1) {
                $value = ($value == (int) $value) ? (int) $value : (double) $value;
                return $value;
            } elseif ($test === 0) {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in date format "Y-m-d" or not.
     * @param string $value <br> The date want check its format. <p></p>
     * @return string <b>Date</b> on success or <b>FALSE</b> on failure.
     */
    public function isDate($value) {
        $value = trim(urldecode($value));
        if (strlen($value) <= 10 && strlen($value) >= 8) {
            $test = preg_match('/^((20|19)[0-9]{2}-([0]?[1-9]|1[0-2])-([0-2]?[0-9]|3[0-1])$)/', $value);
            if ($test === 0) {
                return FALSE;
            }
            $value = $this->escapeString($value);
            return $value;
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in time format "H:i:s" or not.
     * @param string $value <br> The time want check its format. <p></p>
     * @return string <b>Time</b> on success or <b>FALSE</b> on failure.
     */
    public function isTime($value) {
        $value = trim(urldecode($value));
        if (strlen($value) >= 3 && strlen($value) <= 5) {
            $test = preg_match('/^(([0-1]?[0-9]|2[0-3]):([0-5]?[0-9])$)/', $value);
            if ($test === 0) {
                return FALSE;
            }
            $value = $this->escapeString($value);
            return $value;
        } elseif (strlen($value) >= 6 && strlen($value) <= 8) {
            $test = preg_match('/^(([0]?[0-9]|1[0-2]|2[0-3]):([0-5]?[0-9] (AM|am|PM|pm))$)/', $value);
            if ($test === 0) {
                return FALSE;
            }
            $value = $this->escapeString($value);
            return $value;
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in date time format "Y-m-d H:i:s" or not.
     * @param string $value <br> The date time want check its format. <p></p>
     * @return string <b>Date Time</b> on success or <b>FALSE</b> on failure.
     */
    public function isDateTime($value) {
        $value = trim(urldecode($value));
        if (strlen($value) <= 16 && strlen($value) >= 12) {
            $test = preg_match('/^((20|19)[0-9]{2}-([0]?[1-9]|1[0-2])-([0-2]?[0-9]|3[0-1]) ([0-1]?[0-9]|2[0-3]):([0-5]?[0-9])$)/', $value);
            if ($test === 0) {
                return FALSE;
            }
            $value = $this->escapeString($value);
            return $value;
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in latitude format to use with google map or not.
     * @param string $value <br> The date latitude want check its format. <p></p>
     * @return string <b>Latitude</b> on success or <b>FALSE</b> on failure.
     */
    public function isLatitude($value) {
        $value = trim(urldecode($value));
        $value = $this->escapeString($value);
        if (is_numeric($value)) {
            $test = preg_match('/^([0-7]?[0-9][\.][0-9]{2,12}$|[8][0-4][\.][0-9]{2,12}$|[8][5][\.][0]{1,12}$)/', $value);
            if ($test === 1) {
                $value = ($value == (int) $value) ? (int) $value : (double) $value;
                return $value;
            } elseif ($test === 0) {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }

    /**
     * Check string if it's in longitude format to use with google map or not.
     * @param string $value <br> The date longitude want check its format. <p></p>
     * @return string <b>Longitude</b> on success or <b>FALSE</b> on failure.
     */
    public function isLongitude($value) {
        $value = trim(urldecode($value));
        $value = $this->escapeString($value);
        if (is_numeric($value)) {
            $test = preg_match('/^([0-1]?[0-9]{2}[\.][0-9]{2,12}$|[2][0-6][0-9][\.][0-9]{2,12}$|[2][7][0][\.][0]{1,12}$)/', $value);
            if ($test === 1) {
                $value = ($value == (int) $value) ? (int) $value : (double) $value;
                return $value;
            } elseif ($test === 0) {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }

    /**
     * Format time in seconds from spassfic time stamp to time duration format format <br> Like articles from 3 Days, 5 Hours or 30 Minutes.
     * @param int $seconds <br> The seconds from spassfic time. <p></p>
     * @param string $language <br> Have one from two values (<b>'en' or 'ar'</b>) case insensitive. <p></p>
     * @return string <b>String</b> have duration from spassfic time <b>Empty</b> on failure.
     */
    public function getDuration($seconds, $language = 'en') {
        $language = strtolower($language);
        if (!is_numeric($seconds)) {
            return '';
        }
        $message;
        if ($seconds < 3600) {
            if ($language === 'en') {
                if ($seconds < 300) {
                    $message = 'Just now';
                } elseif ($seconds <= 1800) {
                    $minute = ceil($seconds / 60);
                    $message = $minute . ' Minutes';
                } else {
                    $message = 'Less than a hour';
                }
            } elseif ($language === 'ar') {
                if ($seconds < 300) {
                    $message = 'الآن';
                } elseif ($seconds <= 1800) {
                    $minute = ceil($seconds / 60);
                    $message = $minute . ' دقيقة';
                } else {
                    $message = 'أقل من ساعة';
                }
            }
        } elseif ($seconds >= 3600 && $seconds < 86400) {
            $hour = ceil($seconds / 3600);
            if ($language === 'en') {
                $message = $hour . ' hour(s)';
            } else {
                $message = $hour . ' ساعة';
            }
        } elseif ($seconds >= 86400 && $seconds < 2592000) {
            $day = ceil($seconds / 86400);
            if ($language === 'en') {
                $message = $day . ' day(s)';
            } else {
                $message = $day . ' يوم';
            }
        } elseif ($seconds >= 2592000 && $seconds < 31536000) {
            $month = ceil($seconds / 2592000);
            if ($language === 'en') {
                $message = $month . ' month(s)';
            } else {
                $message = $month . ' شهر';
            }
        } else {
            if ($language === 'en') {
                $message = 'More than a year';
            } else {
                $message = 'أكثر من سنة';
            }
        }
    }

    /**
     * Escap string from space at the began and end of text, slashs, special characters and HTML tags entities.
     * @param string $value <br> The string want Escaping it. <p></p>
     * @return string <b>Text</b> after Escaping it.
     */
    public function escapeString($value) {
        $str = htmlentities(trim(urldecode($value)));
        $str = preg_replace_callback('/\\\\u(\w{4})/', function ($matches) {
            return html_entity_decode('&#x' . $matches[1] . ';', ENT_COMPAT, 'UTF-8');
        }, $str);
        return $str;
    }

    /**
     * Get the timestamp of specific date time or current date time.
     * @param string $date <br> The date time formated 'Y-m-d H:i' or '0' to get current timestamp. <p></p>
     * @return int <br> The time stamp of date time.
     */
    public function getTimeStamp($date = '0') {
        if ($date !== '0') {
            return strtotime($date) + 7200;
        } else {
            $dt = new DateTime();
            return ((int) $dt->getTimestamp() + 7200);
        }
    }

    /**
     * Get the date from timestamp.
     * @param int $timeStamp <br> The timestamp value. <p></p>
     * @return string <br> The date in format 'Y-m-d'.
     */
    public function getDateFromTimeStamp($timeStamp) {
        return gmdate("Y-m-d", $timeStamp);
    }

    /**
     * Get the date time from timestamp.
     * @param int $timeStamp <br> The timestamp value. <p></p>
     * @return string <br> The date time in format 'Y-m-d H:i'.
     */
    public function getDateTimeFromTimeStamp($timeStamp) {
        return gmdate("Y-m-d H:i", $timeStamp);
    }

    /**
     * Add positive or negative number of days to timestamp.
     * @param int $timeStamp <br> The timestamp value. <p></p>
     * @param int $daysNo <br> Positive or negative number of days to add to sum to timestamp. <p></p>
     * @return int <br> The new timestamp after adding value.
     */
    public function addDayesToTimeStamp($timeStamp, $daysNo) {
        $total = $timeStamp + ($daysNo * 86400);
        return $total;
    }

}
