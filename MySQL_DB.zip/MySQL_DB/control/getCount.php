<?php

include_once '../source/MySQL_DB.class.php';
include_once '../source/verification.class.php';

$db = new MySQL_DB('store', 'localhost', 'root', '');

echo 'The customer count is: ' . $db->table_count('customer');

