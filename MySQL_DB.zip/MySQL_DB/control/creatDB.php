<?php

include_once '../source/MySQL_DB.class.php';

$db = new MySQL_DB('', 'localhost', 'root', '');

if (!$db->checkDatabaseExist('store')) {
    $db->createDatabase('store');

    $customerFields = [
        ['n' => 'id', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'Auto increment table id'],
        ['n' => 'name', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 50, 'c' => 'The customer name'],
        ['n' => 'email', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 50, 'c' => 'The customer email'],
        ['n' => 'address', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 100, 'd' => '', 'c' => 'The customer main addreess for shipping'],
        ['n' => 'notes', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 200, 'd' => '', 'c' => 'The notes about customer']
    ];
    $db->createTable('customer', $customerFields, 'id', true, 'Customer data', true, 'store');
    $db->addTableIndex('customer', 'email', 'store');
    $db->addTableUnique('customer', 'email', 'store');

    $telFields = [
        ['n' => 'id', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'Auto increment table id'],
        ['n' => 'custmerID', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'The customer ID from table customer'],
        ['n' => 'tel', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 15, 'c' => 'The customer telephone']
    ];
    $db->createTable('telephone', $telFields, 'id', true, 'Customer telephone data', true, 'store');
    $db->addTableUnique('telephone', 'tel', 'store');

    $db->addTablesRelation('telephone', 'custmerID', 'customer', 'id', MySQL_DB::RELATION_NO_ACTION, MySQL_DB::RELATION_CASCADE, 'store');

    $viewFields = [
        ['t' => 'customer', 'c' => 'id', 'n' => 'custmerID'],
        ['t' => 'customer', 'c' => 'name'],
        ['t' => 'customer', 'c' => 'email'],
        ['t' => 'customer', 'c' => 'address'],
        ['t' => 'telephone', 'c' => 'tel']
    ];
    $linked = [['t1' => 'customer', 'c1' => 'id', 't2' => 'telephone', 'c2' => 'custmerID']];
    $db->creatView('customer_tel', $viewFields, $linked, [['t' => 'customer', 'f' => 'notes', 'o' => '<>', 'v' => '']], 'AND', true, 'store');
    
    echo 'Creat database compleat.';
}else{
    echo 'Database already exist';
}

