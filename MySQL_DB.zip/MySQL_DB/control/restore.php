<?php

include_once '../source/MySQL_DB.class.php';
$db = new MySQL_DB('', 'localhost', 'root', '');

if(isset($_POST['file'])){
    $file =  '../backup/' . $_POST['file'];
    if(is_file($file)){
        $db->restoreDatabase($file);
    }else{
        
    }
}else{
    
}


