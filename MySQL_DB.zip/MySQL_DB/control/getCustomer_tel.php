<?php

include_once '../source/MySQL_DB.class.php';

$db = new MySQL_DB('store', 'localhost', 'khaled', 'khmm');

$customer_tel = $db->select(['custmerID', 'name', 'email', 'address', 'tel'], 'customer_tel', []);
if (is_array($customer_tel)) {
    echo json_encode($customer_tel);
} else {
    echo json_encode([]);
}

