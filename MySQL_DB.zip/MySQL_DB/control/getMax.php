<?php

include_once '../source/MySQL_DB.class.php';
include_once '../source/verification.class.php';

$db = new MySQL_DB('store', 'localhost', 'root', '');

echo 'The maximum customer ID is: ' . $db->column_max('customer', 'id');

