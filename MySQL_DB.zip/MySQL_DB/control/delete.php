<?php

include_once '../source/MySQL_DB.class.php';
include_once '../source/verification.class.php';

$db = new MySQL_DB('store', 'localhost', 'khaled', 'khmm');
$check = new verification();

if(isset($_POST['id'])){
    $id = $check->isNumeric($_POST['id']);
    if($id === false){
        echo 'Wrong ID';
    }
}else{
    echo 'Wrong ID';
}

$val = $db->delete('customer', $id);

if(!$val){
    echo 'Can\'t delete this customer';
}else{
    echo $id;
}