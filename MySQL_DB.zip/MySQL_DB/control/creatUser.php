<?php

include_once '../source/MySQL_DB.class.php';

$db = new MySQL_DB('', 'localhost', 'root', '');

if (!$db->checkUserExist('khaled', 'localhost')) {
    $db->creatUser('khaled', 'khmm', 'localhost', [MySQL_DB::PERMISSION_SELECT, MySQL_DB::PERMISSION_INSERT, MySQL_DB::PERMISSION_UPDATE, MySQL_DB::PERMISSION_DELETE]);
    $db->addUserToDB('khaled', 'store', 'localhost', [MySQL_DB::PERMISSION_SELECT, MySQL_DB::PERMISSION_INSERT, MySQL_DB::PERMISSION_UPDATE, MySQL_DB::PERMISSION_DELETE]);

    echo 'Creat user compleat.';
}else{
    echo 'User already exist';
}

