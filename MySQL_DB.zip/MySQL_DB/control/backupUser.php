<?php

include_once '../source/MySQL_DB.class.php';

$db = new MySQL_DB('', 'localhost', 'root', '', 0, '../backup/');

echo $db->BackupAllUsers();
