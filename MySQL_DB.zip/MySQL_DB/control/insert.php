<?php

include_once '../source/MySQL_DB.class.php';
include_once '../source/verification.class.php';

$db = new MySQL_DB('store', 'localhost', 'khaled', 'khmm');
$check = new verification();

if(isset($_POST['name'])){
    $name = $check->isString($_POST['name'], 50, 3);
    if($name === false){
        echo 'Wrong data';
    }
}else{
    echo 'Wrong data';
}
if(isset($_POST['email'])){
    $email = $check->isEmail($_POST['email']);
    if($email === false){
        echo 'Wrong data';
    }
}else{
    echo 'Wrong data';
}
if(isset($_POST['address'])){
    $address = $check->isNumeric($_POST['address']);
    if($address === false){
        $address = '';
    }
}else{
    $address = '';
}
if(isset($_POST['notes'])){
    $notes = $check->isNumeric($_POST['notes']);
    if($notes === false){
        $notes = '';
    }
}else{
    $notes = '';
}
if(isset($_POST['tel'])){
    $temp = json_decode($_POST['tel'], true);
    if(!is_array($temp)){
        $tel = [];
    }else{
        $tel = [];
        for($i = 0; $i < count($temp); $i++){
            $t = $check->isTel($temp[$i]['t']);
            if($t){
                $tel[] = $t;
            }
        }
    }
}else{
    $tel = [];
}

$val = $db->insert(['name' => $name, 'email' => $email, 'address' => $address, 'notes' => $notes], 'customer');

if(!$val){
    echo 'Can\'t insert this customer';
}else{
    for($i = 0; $i < count($tel); $i++){
        $db->insert(['custmerID' => $val, 'tel' => $tel[$i]], 'telephone');
    }
    echo $val;
}