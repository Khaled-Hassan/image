<?php

include_once '../source/MySQL_DB.class.php';

$db = new MySQL_DB('store', 'localhost', 'khaled', 'khmm');

$tenp = $db->select(['id', 'name', 'email', 'address', 'notes'], 'customer', []);
if (is_array($tenp)) {
    $customer = [];
    for ($i = 0; $i < count($tenp); $i++) {
        $id = $tenp[$i]['id'];
        $telData = getTelData($id);
        $tel = [];
        for ($n = 0; $n < count($telData); $n++) {
            $tel[] = $telData[$n]['tel'];
        }

        $customer[] = ['id' => $id, 'name' => $tenp[$i]['name'], 'email' => $tenp[$i]['email'], 'address' => $tenp[$i]['address'], 'notes' => $tenp[$i]['notes'], 'tel' => $tel];
    }

    echo json_encode($customer);
} else {
    echo json_encode([]);
}

function getTelData($id) {
    global $db;

    $tenp = $db->select(['tel'], 'telephone', [['f' => 'custmerID', 'o' => '=', 'v' => $id]], 'AND');
    if (is_array($tenp)) {
        return $tenp;
    } else {
        return [];
    }
}
