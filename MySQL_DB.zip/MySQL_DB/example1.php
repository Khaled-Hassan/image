<!DOCTYPE html>
<?php
include_once './source/MySQL_DB.class.php';

creatDatabase();
addData();
updateSumData();
//deleteSumData();

$CustomerData = getCustomerData();
$CustomerTelData = getCustmerTelData();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link type="text/css" href="css/style.css" rel="stylesheet">
        <script type="text/javascript" src="js/ajax.js"></script>
        <script type="text/javascript" src="js/verification.js"></script>
        <script type="text/javascript" src="js/function.js"></script>
    </head>
    <body>
        <?php
        $db = new MySQL_DB('', 'localhost', 'root', '');
    
        $database = $db->checkDatabaseExist('store');
        if ($database) {
            echo '<p>Found database store</p>';
        }
        
        $table = $db->checkTableExist('store', 'customer');
        if ($table) {
            echo '<p>Found table customer</p>';
        }
        
        $view = $db->checkViewExist('store', 'customer_tel');
        if ($view) {
            echo '<p>Found view customer_tel</p>';
        }
        
        $user = $db->checkUserExist('khaled', 'localhost');
        if ($user) {
            echo '<p>Found user khaled in localhost</p>';
        }
        
        if (checkValue('01111111111') > 0) {
            echo '<p>Found tel No. 01111111111 </p>';
        } else {
            echo '<p>Mot found tel No. 01111111111 </p>';
        }

        echo '<p>Maximum id: ' . getMax() . '</p>';
        echo '<p>Minimum id: ' . getMin() . '</p>';
        echo '<p>Average id: ' . getAverage() . '</p>';
        ?>
        <table class="table" id="customer">
            <thead>
                <tr>
                    <td class="id">ID</td>
                    <td class="text">Name</td>
                    <td class="text">Email</td>
                    <td class="text">Address</td>
                    <td class="text">Notes</td>
                    <td class="text">Tel</td>
                </tr>
            </thead>
            <tbody>
                <?php
                for ($i = 0; $i < count($CustomerData); $i++) {
                    $id = $CustomerData[$i]['id'];
                    $name = $CustomerData[$i]['name'];
                    $email = $CustomerData[$i]['email'];
                    $address = $CustomerData[$i]['address'];
                    $notes = $CustomerData[$i]['notes'];
                    $tel = getTelData($id);
                    $telText = '';
                    for ($n = 0; $n < count($tel); $n++) {
                        $telText .= $tel[$n]['tel'] . '<br>';
                    }
                    ?>
                    <tr>
                        <td class="id"><?php echo $id; ?></td>
                        <td class="text"><?php echo $name; ?></td>
                        <td class="text"><?php echo $email; ?></td>
                        <td class="text"><?php echo $address; ?></td>
                        <td class="text"><?php echo $notes; ?></td>
                        <td class="text"><?php echo $telText; ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
        <table class="table" id="customerTel">
            <thead>
                <tr>
                    <td class="id">ID</td>
                    <td class="text">Name</td>
                    <td class="text">Email</td>
                    <td class="text">Address</td>
                    <td class="text">Tel</td>
                </tr>
            </thead>
            <tbody>
                <?php
                for ($i = 0; $i < count($CustomerTelData); $i++) {
                    $id = $CustomerTelData[$i]['custmerID'];
                    $name = $CustomerTelData[$i]['name'];
                    $email = $CustomerTelData[$i]['email'];
                    $address = $CustomerTelData[$i]['address'];
                    $tel = $CustomerTelData[$i]['tel'];
                    ?>
                    <tr>
                        <td class="id"><?php echo $id; ?></td>
                        <td class="text"><?php echo $name; ?></td>
                        <td class="text"><?php echo $email; ?></td>
                        <td class="text"><?php echo $address; ?></td>
                        <td class="text"><?php echo $tel; ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </body>
</html>
<?php

function creatDatabase() {
    $db = new MySQL_DB();
    $db->databaseName = '';
    $db->host = 'localhost';
    $db->user = 'root';
    $db->password = '';
    $db->connect();

    $db->dropDatabase('store');
    $db->createDatabase('store');
    $db->creatUser('khaled', 'khmm', 'localhost', [MySQL_DB::PERMISSION_SELECT, MySQL_DB::PERMISSION_INSERT, MySQL_DB::PERMISSION_UPDATE, MySQL_DB::PERMISSION_DELETE]);
    $db->addUserToDB('khaled', 'store', 'localhost', [MySQL_DB::PERMISSION_SELECT, MySQL_DB::PERMISSION_INSERT, MySQL_DB::PERMISSION_UPDATE, MySQL_DB::PERMISSION_DELETE]);

    $customerFields = [
        ['n' => 'id', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'Auto increment table id'],
        ['n' => 'name', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 50, 'c' => 'The customer name'],
        ['n' => 'email', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 50, 'c' => 'The customer email'],
        ['n' => 'address', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 100, 'd' => '', 'c' => 'The customer main addreess for shipping']
    ];
    $db->createTable('customer', $customerFields, 'id', true, 'Customer data', true, 'store');
    $db->addTableColumn('customer', [['n' => 'notes', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 200, 'd' => '', 'c' => 'The notes about customer']], 'address', 'store');
    $db->addTableIndex('customer', 'email', 'store');
    $db->addTableUnique('customer', 'email', 'store');

    $telFields = [
        ['n' => 'id', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'd' => MySQL_DB::DEFAULT_NOT_NULL, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'Auto increment table id'],
        ['n' => 'custmerID', 't' => MySQL_DB::TYPE_INT, 'l' => 10, 'a' => MySQL_DB::ATTRIBUTES_UNSIGNED, 'c' => 'The customer ID from table customer'],
        ['n' => 'tel', 't' => MySQL_DB::TYPE_VARCHAR, 'l' => 15, 'c' => 'The customer telephone']
    ];
    $db->createTable('telephone', $telFields, 'id', true, 'Customer telephone data', true, 'store');
    $db->addTableUnique('telephone', 'tel', 'store');

    $db->addTablesRelation('telephone', 'custmerID', 'customer', 'id', MySQL_DB::RELATION_NO_ACTION, MySQL_DB::RELATION_CASCADE, 'store');

    $db->createTable('test', $customerFields, 'id', true, 'test drop only', true, 'store');
    $db->addTableIndex('test', 'email', 'store');
    $db->addTableUnique('test', 'email', 'store');
    $db->dropTableColumn('test', ['address'], 'store');
    $db->dropTableInex('test', 'email', 'store');
    $db->dropTableUnique('test', 'email', 'store');
    $db->truncateTable('test', 'store');
    $db->dropTable('test', 'store');

    $viewFields = [
        ['t' => 'customer', 'c' => 'id', 'n' => 'custmerID'],
        ['t' => 'customer', 'c' => 'name'],
        ['t' => 'customer', 'c' => 'email'],
        ['t' => 'customer', 'c' => 'address'],
        ['t' => 'telephone', 'c' => 'tel']
    ];
    $linked = [['t1' => 'customer', 'c1' => 'id', 't2' => 'telephone', 'c2' => 'custmerID']];
    $db->creatView('customer_tel', $viewFields, $linked, [['t' => 'customer', 'f' => 'notes', 'o' => '<>', 'v' => '']], 'AND', true, 'store');

    echo '<p>Creat database</p>';
}

function addData() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $cust1 = $db->insert(['name' => 'Ahmed', 'email' => 'ahmed@test.com', 'address' => '', 'notes' => ''], 'customer', 'store');
    $db->insert(['custmerID' => $cust1, 'tel' => '0123456789'], 'telephone');
    $db->insert(['custmerID' => $cust1, 'tel' => '0123456111'], 'telephone');
    $cust2 = $db->insert(['name' => 'Mohammad', 'email' => 'mohammad@test.com', 'address' => 'Cairo', 'notes' => ''], 'customer');
    $db->insert(['custmerID' => $cust2, 'tel' => '0122226789'], 'telephone');
    $db->insert(['custmerID' => $cust2, 'tel' => '0133356111'], 'telephone');
    $cust3 = $db->insert(['name' => 'Omar', 'email' => 'omar@test.com', 'address' => 'Alex', 'notes' => ''], 'customer');
    $cust4 = $db->insert(['name' => 'Aly', 'email' => 'aly@test.com', 'address' => '', 'notes' => 'New customer'], 'customer');
    $db->insert(['custmerID' => $cust4, 'tel' => '0122226999'], 'telephone');
    $cust5 = $db->insert(['name' => 'Ossama', 'email' => 'ossama@test.com', 'address' => 'Aswan', 'notes' => ''], 'customer');


    echo '<p>Insert data into database</p>';
}

function updateSumData() {
    $db = new MySQL_DB('store', 'localhost', 'khaled', 'khmm');

    $db->update(['notes' => 'Jsut test update'], 'customer', 1);
    $db->multiUpdate(['tel' => '01111111111'], 'telephone', [['f' => 'custmerID', 'o' => '=', 'v' => 4]]);

    echo '<p>Update data in database</p>';
}

function deleteSumData() {
    $db = new MySQL_DB('store', 'localhost', 'khaled', 'khmm');
    $db->multiDelete('telephone', [['f' => 'custmerID', 'o' => '=', 'v' => 4]]);
    $db->delete('customer', 2);

    echo '<p>Delete data from database</p>';
}

function getCustomerData() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $tenp = $db->select(['id', 'name', 'email', 'address', 'notes'], 'customer', []);
    if (is_array($tenp)) {
        return $tenp;
    } else {
        return [];
    }
}

function getTelData($id) {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $tenp = $db->select(['tel'], 'telephone', [['f' => 'custmerID', 'o' => '=', 'v' => $id]], 'AND');
    if (is_array($tenp)) {
        return $tenp;
    } else {
        return [];
    }
}

function getCustmerTelData() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $tenp = $db->select(['custmerID', 'name', 'email', 'address', 'tel'], 'customer_tel', []);
    if (is_array($tenp)) {
        return $tenp;
    } else {
        return [];
    }
}

function checkValue($tel) {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $temp = $db->check_value_exist('telephone', [['f' => 'tel', 'o' => '=', 'v' => $tel]]);

    return $temp;
}

function getMax() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $temp = $db->column_max('customer', 'id', [['f' => 'id', 'o' => '>', 'v' => 0]]);

    return $temp;
}

function getMin() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $temp = $db->column_Min('customer', 'id', [['f' => 'id', 'o' => '>', 'v' => 0]]);

    return $temp;
}

function getAverage() {
    $db = new MySQL_DB();
    $db->connect('store', 'localhost', 'khaled', 'khmm');

    $temp = $db->column_avarage('customer', 'id');

    return $temp;
}
