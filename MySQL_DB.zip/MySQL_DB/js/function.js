function creatDB() {
    AJAX.call('control/creatDB.php', 'POST', [], false, 'confirmCreatDB');
}

function confirmCreatDB(request) {
    document.getElementById('message').innerHTML = request;
}

function creatUser() {
    AJAX.call('control/creatUser.php', 'POST', [], false, 'confirmCreatUser');
}

function confirmCreatUser(request) {
    document.getElementById('message').innerHTML = request;
}

function insertTable() {
    var param = [];
    param['name'] = verification.isString(document.getElementById('name').value, 50, 5);
    param['email'] = verification.isEmail(document.getElementById('email').value);
    param['address'] = verification.isString(document.getElementById('address').value, 100, 0);
    param['notes'] = verification.isString(document.getElementById('notes').value, 200, 0);

    var telText = document.getElementById('tel').value.replace('<br>', ',');
    telText = telText.split("\n");
    param['tel'] = '[' + telText + ']';

    if (!param['name']) {
        document.getElementById('message').innerHTML = 'Wrong data';
        document.getElementById('name').setAttribute('class', 'wrong');
        return;
    } else {
        document.getElementById('name').removeAttribute('class');
    }
    if (!param['email']) {
        document.getElementById('message').innerHTML = 'Wrong data';
        document.getElementById('email').setAttribute('class', 'wrong');
        return;
    } else {
        document.getElementById('email').removeAttribute('class');
    }

    AJAX.call('control/insert.php', 'POST', param, false, 'confirmInsertTable');
}

function confirmInsertTable(request) {
    if (request === 'Wrong data' || request === 'Can\'t insert this customer') {
        document.getElementById('message').innerHTML = request;
    } else {
        var tel = document.getElementById('tel').value.replace('\n', '<br>');

        var temp = '<tr id="c' + request + '"><td class="id">' + request + '</td><td class="text">';
        temp += document.getElementById('name').value + '</td><td class="text">' + document.getElementById('email').value;
        temp += '</td><td class="text">' + document.getElementById('address').value + '</td><td class="text">';
        temp += document.getElementById('notes').value + '</td><td class="text">' + tel + '</td><td class="operation">';
        temp += '<i class="fa fa-edit" onclick="editCustomer(this.parentNode.parentNode)" title="Edit this customer"></i>';
        temp += '<i class="fa fa-trash" onclick="deleteTable(' + request + ')" title="Delete this customer"></i></td></tr>';
        document.getElementById('customersData').innerHTML += temp;

        document.getElementById('name').value = '';
        document.getElementById('email').value = '';
        document.getElementById('address').value = '';
        document.getElementById('notes').value = '';
        document.getElementById('tel').value = '';

        document.getElementById('message').innerHTML = 'Insert customer successfully';
    }
}

function editCustomer(row) {
    var val = elementChildren(row);
    document.getElementById('id').value = val[0].innerHTML;
    document.getElementById('name').value = val[1].innerHTML;
    document.getElementById('email').value = val[2].innerHTML;
    document.getElementById('address').value = val[3].innerHTML;
    document.getElementById('notes').value = val[4].innerHTML;
    var tel = val[5].innerHTML;
    document.getElementById('tel').value = tel.replace(/<br>/g, "\n");

}

function updateTable() {
    var param = [];
    param['id'] = verification.isNumeric(document.getElementById('id').value, 50, 5);
    param['name'] = verification.isString(document.getElementById('name').value, 50, 5);
    param['email'] = verification.isEmail(document.getElementById('email').value);
    param['address'] = verification.isString(document.getElementById('address').value, 100, 0);
    param['notes'] = verification.isString(document.getElementById('notes').value, 200, 0);

    var telText = document.getElementById('tel').value.replace('<br>', ',');
    telText = telText.split("\n");
    param['tel'] = '[' + telText + ']';

    if (!param['id']) {
        document.getElementById('message').innerHTML = 'Wrong data';
        return;
    }
    if (!param['name']) {
        document.getElementById('message').innerHTML = 'Wrong data';
        document.getElementById('name').setAttribute('class', 'wrong');
        return;
    } else {
        document.getElementById('name').removeAttribute('class');
    }
    if (!param['email']) {
        document.getElementById('message').innerHTML = 'Wrong data';
        document.getElementById('email').setAttribute('class', 'wrong');
        return;
    } else {
        document.getElementById('email').removeAttribute('class');
    }

    AJAX.call('control/update.php', 'POST', param, false, 'confirmUpdateTable');
}

function confirmUpdateTable(request) {
    if (request === 'Wrong data' || request === 'Can\'t update this customer') {
        document.getElementById('message').innerHTML = request;
    } else {
        var telText = document.getElementById('tel').value.split("\n"), tel = '';
        for (var i = 0; i < telText.length; i++) {
            tel += telText[i] + '<br>';
        }

        var temp = '<td class="id">' + request + '</td><td class="text">' + document.getElementById('name').value;
        temp += '</td><td class="text">' + document.getElementById('email').value + '</td><td class="text">';
        temp += document.getElementById('address').value + '</td><td class="text">' + document.getElementById('notes').value;
        temp += '</td><td class="text">' + tel + '</td><td class="operation">';
        temp += '<i class="fa fa-edit" onclick="editCustomer(this.parentNode.parentNode)" title="Edit this customer"></i>';
        temp += '<i class="fa fa-trash" onclick="deleteTable(' + request + ')" title="Delete this customer"></i></td>';
        document.getElementById('c' + request).innerHTML = temp;

        document.getElementById('id').value = '';
        document.getElementById('name').value = '';
        document.getElementById('email').value = '';
        document.getElementById('address').value = '';
        document.getElementById('notes').value = '';
        document.getElementById('tel').value = '';

        document.getElementById('message').innerHTML = 'UPdate customer successfully';
    }
}

function deleteTable(id) {
    var param = [];
    param['id'] = verification.isNumeric(id);

    if (!param['id']) {
        document.getElementById('message').innerHTML = 'Wrong data';
        return;
    }

    AJAX.call('control/delete.php', 'POST', param, false, 'confirmDeleteTable');
}

function confirmDeleteTable(request) {
    if (request === 'Wrong data' || request === 'Can\'t delete this customer') {
        document.getElementById('message').innerHTML = request;
    } else {
        document.getElementById('customersData').removeChild(document.getElementById('c' + request));

        document.getElementById('message').innerHTML = 'Delete customer successfully';
    }
}

function getCustomer() {
    AJAX.call('control/getCustomer.php', 'POST', [], true, 'confirmGetCustomer');
}

function confirmGetCustomer(request) {
    var temp = '';
    for (var i = 0; i < request.length; i++) {
        var cur = request[i], id = cur.id, name = cur.name, email = cur.email, address = cur.address, notes = cur.notes, telArray = cur.tel, tel = '';
        for (var n = 0; n < telArray.length; n++) {
            tel += telArray[n] + '<br>';
        }

        temp += '<tr id="c' + id + '"><td class="id">' + id + '</td><td class="text">' + name + '</td><td class="text">';
        temp += email + '</td><td class="text">' + address + '</td><td class="text">' + notes ;
        temp += '</td><td class="text">' + tel + '</td><td class="operation">';
        temp += '<i class="fa fa-edit" onclick="editCustomer(this.parentNode.parentNode)" title="Edit this customer"></i>';
        temp += '<i class="fa fa-trash" onclick="deleteTable(' + id + ')" title="Delete this customer"></i></td></tr>';
    }
    document.getElementById('customersData').innerHTML = temp;
}

function getCustomerTel() {
    AJAX.call('control/getCustomer_tel.php', 'POST', [], true, 'confirmGetCustomerTel');
}

function confirmGetCustomerTel(request) {
    var temp = '';
    for (var i = 0; i < request.length; i++) {
        var cur = request[i], id = cur.custmerID, name = cur.name, email = cur.email, address = cur.address, tel = cur.tel;

        temp += '<tr id="c' + id + '"><td class="id">' + id + '</td><td class="text">' + name + '</td><td class="text">';
        temp += email + '</td><td class="text">' + address + '</td><td class="operation">';
        temp += '<i class="fa fa-edit" onclick="editCustomer(this.parentNode.parentNode)" title="Edit this customer"></i>';
        temp += tel + '<i class="fa fa-trash" onclick="deleteTable(' + id + ')" title="Delete this customer"></i></td></tr>';
    }
    document.getElementById('customerTelTableData').innerHTML = temp;
}

function getCount() {
    AJAX.call('control/getCount.php', 'POST', [], false, 'confirmGetCount');
}

function confirmGetCount(request) {
    document.getElementById('message').innerHTML = request;
}

function getAverage() {
    AJAX.call('control/getAverage.php', 'POST', [], false, 'confirmGetAverage');
}

function confirmGetAverage(request) {
    document.getElementById('message').innerHTML = request;
}

function getMax() {
    AJAX.call('control/getMax.php', 'POST', [], false, 'confirmGetMax');
}

function confirmGetMax(request) {
    document.getElementById('message').innerHTML = request;
}

function getMin() {
    AJAX.call('control/getMin.php', 'POST', [], false, 'confirmGetMin');
}

function confirmGetMin(request) {
    document.getElementById('message').innerHTML = request;
}

function backupDB() {
    AJAX.call('control/backup.php', 'POST', [], false);
    document.getElementById('message').innerHTML = 'Backup database.';
}
function backupUser() {
    AJAX.call('control/backupUser.php', 'POST', [], false);
    document.getElementById('message').innerHTML = 'Backup users.';
}

function restoreDB() {
    var param = [];
    param['file'] = verification.isString(getFileName(document.getElementById('restore').value), 100, 20);
    AJAX.call('control/restore.php', 'POST', param, false);
    document.getElementById('message').innerHTML = 'Restor database.';
}

function getFileName(fullPath) {
    if (fullPath) {
        var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
        var filename = fullPath.substring(startIndex);
        if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            filename = filename.substring(1);
        }
        return filename;
    }
}

function elementChildren(element) {
    var childNodes = element.childNodes,
            children = [],
            i = childNodes.length;
    while (i--) {
        if (childNodes[i].nodeType == 1) {
            children.unshift(childNodes[i]);
        }
    }

    return children;
}