/*Must add sha256.js file if remove code in the end or from th net
 <script src="http://crypto-js.googlecode.com/svn/tags/3.1.2/build/rollups/sha256.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.2/rollups/sha256.js"></script>
 */

/**
 * Filter data get from user and chck it if compatible with fields length, format and scape SQL injection <b>using regular_expression</b>.<p></p>
 * @author Khaled Hassan
 * @category Security
 * @link khaled.h.developer@gmail.com
 */
var verification = {
    /**
     * Check string if it's in Email format or not.
     * @param val string <br> The Email want check its format. <p></p>
     * @return string <b>Email</b> on success or <b>FALSE</b> on failure.
     */
    isEmail: function (val) {
        val = this.setting.trim(val);
        var exp = new RegExp(/^[a-zA-Z0-9][a-zA-Z0-9\._-]+@[a-zA-Z0-9_-]+\.[a-zA-Z]{2,4}([\.][a-zA-Z]{2})?$/);
        var test = exp.exec(val);
        if (test !== null) {
            val = encodeURIComponent(val);
            return val;
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in website format or not.
     * @param val string <br> The website want check its format. <p></p>
     * @return string <b>Website</b> on success or <b>FALSE</b> on failure.
     */
    isWebsite: function (val) {
        val = this.setting.trim(val);
        if (val.substr(0, 11) !== 'http://www.') {
            if (val.substr(0, 7) === 'http://') {
                val = 'http://www.' + val.substr(7, val.length);
            } else if (val.substr(0, 4) === 'www.') {
                val = 'http://www.' + val.substr(4, val.length);
            } else {
                val = 'http://www.' + val;
            }
        }
        var exp = new RegExp(/^http:\/\/www\.[a-zA-Z0-9_\.]+\.[a-zA-Z]{2,12}[\.]?[a-zA-Z]?[a-zA-Z]?$/);
        var test = exp.exec(val);
        if (test !== null) {
            val = encodeURIComponent(val);
            return val;
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in IP address format or not.
     * @param val string <br> The IP address want check its format. <p></p>
     * @return string <b>IP address</b> on success or <b>FALSE</b> on failure.
     */
    isIP: function (val) {
        val = this.setting.trim(val);
        if (val.length <= 15) {
            var exp = new RegExp(/^(\d|[01]?\d\d|2[0-4]\d|25[0-5])\.(\d|[01]?\d\d|2[0-4]\d|25[0-5])\.(\d|[01]?\d\d|2[0-4]\d|25[0-5])\.(\d|[01]?\d\d|2[0-4]\d|25[0-5])$/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        }
    },
    /**
     * Check string if it's in telephone number format or not.
     * @param val string <br> The telephone number want check its format. <p></p>
     * @param locale bool <br> <b>TRUR</b> the number in locale area format <b>FALSE</b> the number in international format ex +20 000. <p></p>
     * @return string <b>telephone number</b> on success or <b>FALSE</b> on failure.
     */
    isTel: function (val, locale) {
        if (locale === undefined) {
            locale = false;
        }
        val = this.setting.trim(val);
        if (val.length <= 16) {
            if (locale === true) {
                if (this.setting.isNumerics(val)) {
                    var exp = new RegExp(/^[0][0-9]{6,12}$/);
                    var test = exp.exec(val);
                    if (test === null) {
                        return false;
                    }
                } else {
                    return false;
                }
            } else if (locale === false) {
                var exp = new RegExp(/^([0]|[00]|[+]?[1-9]?[0-9]{8,13})$/);
                var test = exp.exec(val);
                if (test === null) {
                    return false;
                }
            }

            return val;
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in password format have characters and (number or special characters) or not.
     * @param val string <br> The password want check its format. <p></p>
     * @param minLength int <br> The minimum length allowed in password <b>using if passwword not hashed</b>. <p></p>
     * @return string <b>Hashed password</b> on success or <b>FALSE</b> on failure.
     */
    isPassword: function (val, minLength) {
        if (minLength === undefined) {
            minLength = 6;
        }

        val = this.setting.trim(val);
        if (val.length >= minLength) {
            var exp1 = new RegExp(/^[a-zA-Z0-9]{5,18}$/);
            var exp2 = new RegExp(/[0-9]{1,}/);
            var exp3 = new RegExp(/[\$#@!\.\*_-]{1,}/);
            var test1 = exp1.exec(val);
            var test2 = exp2.exec(val);
            var test3 = exp3.exec(val);
            if (test1 !== null && test2 !== null) {
                val = CryptoJS.SHA256(val);
                return val;
            } else if (test1 !== null && test3 !== null) {
                val = CryptoJS.SHA256(val);
                return val;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in number format <b>(integer or floot)</b> or not.
     * @param val string <br> The password want check its format. <p></p>
     * @param haveDecimal bool <br> <b>TRUR</b> the number is floot <b>FALSE</b> the number is integer. <p></p>
     * @return int <b>number</b> on success or <b>FALSE</b> on failure.
     * @return floot <b>number</b> on success or <b>FALSE</b> on failure.
     */
    isNumeric: function (val, haveDecimal) {
        val = val.toString();
        if (haveDecimal === undefined) {
            haveDecimal = false;
        }
        val = this.setting.trim(val);
        if (this.setting.isNumerics(val)) {
            if (haveDecimal === false) {
                val = parseInt(val);
            } else {
                val = parseFloat(val);
            }
            return val;
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in safe databse format or not.
     * @param val string <br> The string want check its format. <p></p>
     * @param max int <br> The maximum length of characters. <p></p>
     * @param min int <br> The minimum length of characters. <p></p>
     * @return string <b>String</b> after escape special characters to safe database on success or <b>FALSE</b> on failure.
     */
    isString: function (val, max, min) {
        val = val.toString();
        if (max === undefined) {
            max = 0;
        }
        if (min === undefined) {
            min = 0;
        }

        val = this.setting.trim(val);
        if (min !== 0) {
            if (val.length < min) {
                return false;
            }
        }

        if (max !== 0) {
            if (val.length > max) {
                return false;
            }
        }

        val = encodeURIComponent(val);
        return val;
    },
    /**
     * Encode HTML string and escape special character like tags "<>" and slash "/" to can save safely in database.
     * @param val string <br> The HTML string want encode it. <p></p>
     * @param max int <br> The maximum length of characters. <p></p>
     * @param min int <br> The minimum length of characters. <p></p>
     * @return string <b>HTML</b> after encode it.
     */
    isHTML: function (val, max, min) {
        if (max === undefined) {
            max = 0;
        }
        if (min === undefined) {
            min = 0;
        }
        val = this.setting.trim(val);
        if (min !== 0) {
            if (val.length < min) {
                return false;
            }
        }

        if (max !== 0) {
            if (val.length > max) {
                return false;
            }
        }

        val = encodeURIComponent(val);
        val = String(val).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        return val;
    },
    /**
     * Decode HTML string to tags to can show in browser.
     * @param val string <br> The string want decode it to HTML. <p></p>
     * @return string <b>HTML</b> after decode it.
     */
    getHTML: function (val) {
        if (val !== '') {
            var code = document.createElement('textarea');
            code.innerHTML = val;
            return code.childNodes[0].nodeValue;
        } else {
            return val;
        }
    },
    /**
     * Check number if it's in mony format or not.
     * @param val string <br> The string want check its format. <p></p>
     * @return int <b>duble</b> on success or <b>FALSE</b> on failure.
     */
    isMony: function (val) {
        val = this.setting.trim(val);
        if (this.setting.isNumerics(val)) {
            var exp = new RegExp(/^[0-9]+([\.]?[0-9]{1,2})?$/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in date format "Y-m-d" or not.
     * @param val string <br> The date want check its format. <p></p>
     * @return string <b>Date</b> on success or <b>FALSE</b> on failure.
     */
    isDate: function (val) {
        val = this.setting.trim(val);
        if (val.length <= 10 && val.length >= 8) {
            var exp = new RegExp(/^((20|19)[0-9]{2}-([0]?[1-9]|1[0-2])-([0-2]?[0-9]|3[0-1]))$/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in time format "H:i:s" or not.
     * @param val string <br> The time want check its format. <p></p>
     * @return string <b>Time</b> on success or <b>FALSE</b> on failure.
     */
    isTime: function (val) {
        val = this.setting.trim(val);
        if (val.length >= 3 && val.length <= 5) {
            var exp = new RegExp(/^(([0-1]?[0-9]|2[0-3]):([0-5]?[0-9]))$/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        } else if (val.length >= 6 && val.length <= 8) {
            var exp = new RegExp(/^(([0]?[1-9]|1[0-2]):([0-5]?[0-9]) (AM|am|PM|pm))$/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in date time format "Y-m-d H:i:s" or not.
     * @param val string <br> The date time want check its format. <p></p>
     * @return string <b>Date Time</b> on success or <b>FALSE</b> on failure.
     */
    isDateTime: function (val) {
        val = this.setting.trim(val);
        if (val.length <= 16 && val.length >= 12) {
            var exp = new RegExp(/^((20|19)[0-9]{2}-([0]?[1-9]|1[0-2])-([0-2]?[0-9]|3[0-1]) ([0-1]?[0-9]|2[0-3]):([0-5]?[0-9])$)/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in latitude format to use with google map or not.
     * @param val string <br> The date latitude want check its format. <p></p>
     * @return string <b>Latitude</b> on success or <b>FALSE</b> on failure.
     */
    isLatitude: function (val) {
        val = this.setting.trim(val);
        if (this.setting.isNumerics(val)) {
            var exp = new RegExp(/^([0-7]?[0-9][\.][0-9]{4,12}$|[8][0-4][\.][0-9]{4,12}$|[8][5][\.][0]{1,12}$)/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    /**
     * Check string if it's in longitude format to use with google map or not.
     * @param val string <br> The date longitude want check its format. <p></p>
     * @return string <b>Longitude</b> on success or <b>FALSE</b> on failure.
     */
    isLongitude: function (val) {
        val = this.setting.trim(val);
        if (this.setting.isNumerics(val)) {
            var exp = new RegExp(/^([0-1]?[0-9]{2}[\.][0-9]{4,12}$|[2][0-6][0-9][\.][0-9]{4,12}$|[2][7][0][\.][0]{1,12}$)/);
            var test = exp.exec(val);
            if (test !== null) {
                val = encodeURIComponent(val);
                return val;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    /**
     * Format time in seconds from spassfic time stamp to time duration format format <br> Like articles from 3 Days, 5 Hours or 30 Minutes.
     * @param seconds int <br> The seconds from spassfic time. <p></p>
     * @param language string <br> Have one from two values (<b>'en' or 'ar'</b>) case insensitive. <p></p>
     * @return string <b>String</b> have duration from spassfic time <b>Empty</b> on failure.
     */
    getDuration: function (seconds, language) {
        if (language === undefined) {
            language = 'en';
        }
        language = language.toLowerCase();
        if (this.setting.isNumerics(seconds)) {
            seconds = parseInt(seconds);
            var timeNow = parseInt(parseInt(new Date().getTime()) / 1000);
            seconds = timeNow - seconds;
            var message;
            if (seconds < 3600) {
                if (language === 'en') {
                    if (seconds < 300) {
                        message = 'Just now';
                    } else if (seconds <= 1800) {
                        var minute = parseInt(seconds / 60);
                        message = minute + ' Minutes';
                    } else {
                        message = 'Less than a hour';
                    }
                } else if (language === 'ar') {
                    if (seconds < 300) {
                        message = 'الآن';
                    } else if (seconds <= 1800) {
                        var minute = parseInt(seconds / 60);
                        message = minute + ' دقيقة';
                    } else {
                        message = 'أقل من ساعة';
                    }
                }
            } else if (seconds >= 3600 && seconds < 86400) {
                var hour = parseInt(seconds / 3600);
                if (language === 'en') {
                    message = hour + ' hour(s)';
                } else {
                    message = hour + ' ساعة';
                }
            } else if (seconds >= 86400 && seconds < 2592000) {
                var day = parseInt(seconds / 86400);
                if (language === 'en') {
                    message = day + ' day(s)';
                } else {
                    message = day + ' يوم';
                }
            } else if (seconds >= 2592000 && seconds < 31536000) {
                var month = parseInt(seconds / 2592000);
                if (language === 'en') {
                    message = month + ' month(s)';
                    ;
                } else {
                    message = month + ' شهر';
                }
            } else {
                if (language === 'en') {
                    message = 'More than a year';
                } else {
                    message = 'أكثر من سنة';
                }
            }
            return message;
        } else {
            return '';
        }
    },
    setting: {
        trim: function (str) {
            return str.trim();
        },
        isNumerics: function (num) {
            return !isNaN(num);
        }
    }
};

/************************************************************************************************************************/
/* SHA 256 script */
var CryptoJS = CryptoJS || function (h, s) {
    var f = {}, t = f.lib = {}, g = function () {}, j = t.Base = {extend: function (a) {
            g.prototype = this;
            var c = new g;
            a && c.mixIn(a);
            c.hasOwnProperty("init") || (c.init = function () {
                c.$super.init.apply(this, arguments)
            });
            c.init.prototype = c;
            c.$super = this;
            return c
        }, create: function () {
            var a = this.extend();
            a.init.apply(a, arguments);
            return a
        }, init: function () {}, mixIn: function (a) {
            for (var c in a)
                a.hasOwnProperty(c) && (this[c] = a[c]);
            a.hasOwnProperty("toString") && (this.toString = a.toString)
        }, clone: function () {
            return this.init.prototype.extend(this)
        }},
    q = t.WordArray = j.extend({init: function (a, c) {
            a = this.words = a || [];
            this.sigBytes = c != s ? c : 4 * a.length
        }, toString: function (a) {
            return(a || u).stringify(this)
        }, concat: function (a) {
            var c = this.words, d = a.words, b = this.sigBytes;
            a = a.sigBytes;
            this.clamp();
            if (b % 4)
                for (var e = 0; e < a; e++)
                    c[b + e >>> 2] |= (d[e >>> 2] >>> 24 - 8 * (e % 4) & 255) << 24 - 8 * ((b + e) % 4);
            else if (65535 < d.length)
                for (e = 0; e < a; e += 4)
                    c[b + e >>> 2] = d[e >>> 2];
            else
                c.push.apply(c, d);
            this.sigBytes += a;
            return this
        }, clamp: function () {
            var a = this.words, c = this.sigBytes;
            a[c >>> 2] &= 4294967295 <<
                    32 - 8 * (c % 4);
            a.length = h.ceil(c / 4)
        }, clone: function () {
            var a = j.clone.call(this);
            a.words = this.words.slice(0);
            return a
        }, random: function (a) {
            for (var c = [], d = 0; d < a; d += 4)
                c.push(4294967296 * h.random() | 0);
            return new q.init(c, a)
        }}), v = f.enc = {}, u = v.Hex = {stringify: function (a) {
            var c = a.words;
            a = a.sigBytes;
            for (var d = [], b = 0; b < a; b++) {
                var e = c[b >>> 2] >>> 24 - 8 * (b % 4) & 255;
                d.push((e >>> 4).toString(16));
                d.push((e & 15).toString(16))
            }
            return d.join("")
        }, parse: function (a) {
            for (var c = a.length, d = [], b = 0; b < c; b += 2)
                d[b >>> 3] |= parseInt(a.substr(b,
                        2), 16) << 24 - 4 * (b % 8);
            return new q.init(d, c / 2)
        }}, k = v.Latin1 = {stringify: function (a) {
            var c = a.words;
            a = a.sigBytes;
            for (var d = [], b = 0; b < a; b++)
                d.push(String.fromCharCode(c[b >>> 2] >>> 24 - 8 * (b % 4) & 255));
            return d.join("")
        }, parse: function (a) {
            for (var c = a.length, d = [], b = 0; b < c; b++)
                d[b >>> 2] |= (a.charCodeAt(b) & 255) << 24 - 8 * (b % 4);
            return new q.init(d, c)
        }}, l = v.Utf8 = {stringify: function (a) {
            try {
                return decodeURIComponent(escape(k.stringify(a)))
            } catch (c) {
                throw Error("Malformed UTF-8 data");
            }
        }, parse: function (a) {
            return k.parse(unescape(encodeURIComponent(a)))
        }},
    x = t.BufferedBlockAlgorithm = j.extend({reset: function () {
            this._data = new q.init;
            this._nDataBytes = 0
        }, _append: function (a) {
            "string" == typeof a && (a = l.parse(a));
            this._data.concat(a);
            this._nDataBytes += a.sigBytes
        }, _process: function (a) {
            var c = this._data, d = c.words, b = c.sigBytes, e = this.blockSize, f = b / (4 * e), f = a ? h.ceil(f) : h.max((f | 0) - this._minBufferSize, 0);
            a = f * e;
            b = h.min(4 * a, b);
            if (a) {
                for (var m = 0; m < a; m += e)
                    this._doProcessBlock(d, m);
                m = d.splice(0, a);
                c.sigBytes -= b
            }
            return new q.init(m, b)
        }, clone: function () {
            var a = j.clone.call(this);
            a._data = this._data.clone();
            return a
        }, _minBufferSize: 0});
    t.Hasher = x.extend({cfg: j.extend(), init: function (a) {
            this.cfg = this.cfg.extend(a);
            this.reset()
        }, reset: function () {
            x.reset.call(this);
            this._doReset()
        }, update: function (a) {
            this._append(a);
            this._process();
            return this
        }, finalize: function (a) {
            a && this._append(a);
            return this._doFinalize()
        }, blockSize: 16, _createHelper: function (a) {
            return function (c, d) {
                return(new a.init(d)).finalize(c)
            }
        }, _createHmacHelper: function (a) {
            return function (c, d) {
                return(new w.HMAC.init(a,
                        d)).finalize(c)
            }
        }});
    var w = f.algo = {};
    return f
}(Math);
(function (h) {
    for (var s = CryptoJS, f = s.lib, t = f.WordArray, g = f.Hasher, f = s.algo, j = [], q = [], v = function (a) {
        return 4294967296 * (a - (a | 0)) | 0
    }, u = 2, k = 0; 64 > k; ) {
        var l;
        a:{
            l = u;
            for (var x = h.sqrt(l), w = 2; w <= x; w++)
                if (!(l % w)) {
                    l = !1;
                    break a
                }
            l = !0
        }
        l && (8 > k && (j[k] = v(h.pow(u, 0.5))), q[k] = v(h.pow(u, 1 / 3)), k++);
        u++
    }
    var a = [], f = f.SHA256 = g.extend({_doReset: function () {
            this._hash = new t.init(j.slice(0))
        }, _doProcessBlock: function (c, d) {
            for (var b = this._hash.words, e = b[0], f = b[1], m = b[2], h = b[3], p = b[4], j = b[5], k = b[6], l = b[7], n = 0; 64 > n; n++) {
                if (16 > n)
                    a[n] =
                    c[d + n] | 0;
                else {
                    var r = a[n - 15], g = a[n - 2];
                    a[n] = ((r << 25 | r >>> 7) ^ (r << 14 | r >>> 18) ^ r >>> 3) + a[n - 7] + ((g << 15 | g >>> 17) ^ (g << 13 | g >>> 19) ^ g >>> 10) + a[n - 16]
                }
                r = l + ((p << 26 | p >>> 6) ^ (p << 21 | p >>> 11) ^ (p << 7 | p >>> 25)) + (p & j ^ ~p & k) + q[n] + a[n];
                g = ((e << 30 | e >>> 2) ^ (e << 19 | e >>> 13) ^ (e << 10 | e >>> 22)) + (e & f ^ e & m ^ f & m);
                l = k;
                k = j;
                j = p;
                p = h + r | 0;
                h = m;
                m = f;
                f = e;
                e = r + g | 0
            }
            b[0] = b[0] + e | 0;
            b[1] = b[1] + f | 0;
            b[2] = b[2] + m | 0;
            b[3] = b[3] + h | 0;
            b[4] = b[4] + p | 0;
            b[5] = b[5] + j | 0;
            b[6] = b[6] + k | 0;
            b[7] = b[7] + l | 0
        }, _doFinalize: function () {
            var a = this._data, d = a.words, b = 8 * this._nDataBytes, e = 8 * a.sigBytes;
            d[e >>> 5] |= 128 << 24 - e % 32;
            d[(e + 64 >>> 9 << 4) + 14] = h.floor(b / 4294967296);
            d[(e + 64 >>> 9 << 4) + 15] = b;
            a.sigBytes = 4 * d.length;
            this._process();
            return this._hash
        }, clone: function () {
            var a = g.clone.call(this);
            a._hash = this._hash.clone();
            return a
        }});
    s.SHA256 = g._createHelper(f);
    s.HmacSHA256 = g._createHmacHelper(f)
})(Math);

