GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'consular'@'localhost' IDENTIFIED BY PASSWORD '*037D560FC1BC371FE05F4983147144EF8A1812BF';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'consular'@'localhost' IDENTIFIED BY PASSWORD '*037D560FC1BC371FE05F4983147144EF8A1812BF';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `jordan_consular`.* TO 'consular'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `jordan_consular`.* TO 'consular'@'localhost';




GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, LOCK TABLES, CREATE VIEW, CREATE ROUTINE, ALTER ROUTINE, EXECUTE, SELECT, TRIGGER, FILE, SHOW DATABASES, SUPER ON *.* TO 'consular_admin'@'localhost' IDENTIFIED BY PASSWORD '*E2BF869FF497FC98203421B86588F35F699F835F' WITH GRANT OPTION;GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, LOCK TABLES, CREATE VIEW, CREATE ROUTINE, ALTER ROUTINE, EXECUTE, SELECT, TRIGGER, FILE, SHOW DATABASES, SUPER ON *.* TO 'consular_admin'@'localhost' IDENTIFIED BY PASSWORD '*E2BF869FF497FC98203421B86588F35F699F835F' WITH GRANT OPTION;

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, CREATE VIEW, EXECUTE, SELECT ON `jordan_consular`.* TO 'consular_admin'@'localhost' WITH GRANT OPTION;GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, CREATE VIEW, EXECUTE, SELECT ON `jordan_consular`.* TO 'consular_admin'@'localhost' WITH GRANT OPTION;

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, CREATE VIEW, EXECUTE, SELECT ON `jordan_consular`.* TO 'consular_admin'@'localhost' WITH GRANT OPTION;GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, CREATE VIEW, EXECUTE, SELECT ON `jordan_consular`.* TO 'consular_admin'@'localhost' WITH GRANT OPTION;GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, CREATE VIEW, EXECUTE, SELECT ON `jordan_consular`.* TO 'consular_admin'@'localhost' WITH GRANT OPTION;

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX, ALTER, CREATE VIEW, EXECUTE, SELECT ON `jordan_consular`.* TO 'consular_admin'@'localhost' WITH GRANT OPTION;




GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'courssaty_user'@'localhost' IDENTIFIED BY PASSWORD '*20D934ADB7ACD27515BE0748E437FAB2F9DBCED3';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'courssaty_user'@'localhost' IDENTIFIED BY PASSWORD '*20D934ADB7ACD27515BE0748E437FAB2F9DBCED3';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `courssaty_db`.* TO 'courssaty_user'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `courssaty_db`.* TO 'courssaty_user'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `courssaty_db`.* TO 'courssaty_user'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `courssaty_db`.* TO 'courssaty_user'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `courssaty_db`.* TO 'courssaty_user'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `courssaty_db`.* TO 'courssaty_user'@'localhost';




GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'khaled'@'localhost' IDENTIFIED BY PASSWORD '*084F4105BC6A9E8B34C6A002D63D18C026E0430E';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'khaled'@'localhost' IDENTIFIED BY PASSWORD '*084F4105BC6A9E8B34C6A002D63D18C026E0430E';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `store`.* TO 'khaled'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `store`.* TO 'khaled'@'localhost';




GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'iats-users'@'localhost' IDENTIFIED BY PASSWORD '*037D560FC1BC371FE05F4983147144EF8A1812BF';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'iats-users'@'localhost' IDENTIFIED BY PASSWORD '*037D560FC1BC371FE05F4983147144EF8A1812BF';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mba`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_cpm`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_academy`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mebd`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_mbde`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_nsp`.* TO 'iats-users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats_tqm`.* TO 'iats-users'@'localhost';




GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'mba_users'@'localhost' IDENTIFIED BY PASSWORD '*037D560FC1BC371FE05F4983147144EF8A1812BF';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'mba_users'@'localhost' IDENTIFIED BY PASSWORD '*037D560FC1BC371FE05F4983147144EF8A1812BF';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats-mba`.* TO 'mba_users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats-mba`.* TO 'mba_users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `mba_data`.* TO 'mba_users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats-mba`.* TO 'mba_users'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `iats-mba`.* TO 'mba_users'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `mba_data`.* TO 'mba_users'@'localhost';




GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'zeus'@'localhost' IDENTIFIED BY PASSWORD '*4283723BCD8D9E28A2175B174DBD3FC4A9B368DB';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'zeus'@'localhost' IDENTIFIED BY PASSWORD '*4283723BCD8D9E28A2175B174DBD3FC4A9B368DB';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `zeus`.* TO 'zeus'@'localhost';GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `zeus`.* TO 'zeus'@'localhost';




