DROP DATABASE IF EXISTS `store`;
CREATE DATABASE `store` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE store;

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Auto increment table id',
  `name` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'The customer name',
  `email` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'The customer email',
  `address` varchar(100) COLLATE utf8_bin NOT NULL COMMENT 'The customer main addreess for shipping',
  `notes` varchar(200) COLLATE utf8_bin NOT NULL COMMENT 'The notes about customer',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email-U` (`email`),
  KEY `email-I` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Customer data';

INSERT INTO `customer` VALUES("1","Ahmed","ahmed@test.com","","Jsut test update");
INSERT INTO `customer` VALUES("2","Mohammad","mohammad@test.com","Cairo","");
INSERT INTO `customer` VALUES("3","Omar","omar@test.com","Alex","");
INSERT INTO `customer` VALUES("4","Aly","aly@test.com","","New customer");
INSERT INTO `customer` VALUES("5","Ossama","ossama@test.com","Aswan","");



DROP TABLE IF EXISTS `telephone`;

CREATE TABLE `telephone` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Auto increment table id',
  `custmerID` int(10) unsigned NOT NULL COMMENT 'The customer ID from table customer',
  `tel` varchar(15) COLLATE utf8_bin NOT NULL COMMENT 'The customer telephone',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tel-U` (`tel`),
  KEY `telephone-custmerID-FK` (`custmerID`),
  CONSTRAINT `telephone-custmerID-FK` FOREIGN KEY (`custmerID`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Customer telephone data';

INSERT INTO `telephone` VALUES("1","1","0123456789");
INSERT INTO `telephone` VALUES("2","1","0123456111");
INSERT INTO `telephone` VALUES("3","2","0122226789");
INSERT INTO `telephone` VALUES("4","2","0133356111");
INSERT INTO `telephone` VALUES("5","4","01111111111");



DROP VIEW IF EXISTS `customer_tel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_tel` AS select `customer`.`id` AS `custmerID`,`customer`.`name` AS `name`,`customer`.`email` AS `email`,`customer`.`address` AS `address`,`telephone`.`tel` AS `tel` from (`customer` join `telephone`) where ((`customer`.`id` = `telephone`.`custmerID`) and (`customer`.`notes` <> ''));




GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON *.* TO 'khaled'@'localhost' IDENTIFIED BY PASSWORD '*084F4105BC6A9E8B34C6A002D63D18C026E0430E';

GRANT SELECT, INSERT, UPDATE, DELETE, SELECT ON `store`.* TO 'khaled'@'localhost';


